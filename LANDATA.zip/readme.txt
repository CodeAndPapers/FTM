generator.py: used for dealing with the original data to get files:
"netflow_day-[Num]-o.txt" "NETedge.txt" "NETnode.txt"

netflow.cpp: codes for dealing with files "netflow_day-[Num]-o.txt" "NETedge.txt" "NETnode.txt" to generate the final dataset

NETedge.txt NETnode.txt: the mapping of edges and nodes for the original data [Days 3-7]
