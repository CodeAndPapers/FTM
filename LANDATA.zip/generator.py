import numpy as np
filename=[]


def write_file(name,list):#写入一个文件，以列表传入
    with open(name,"w",encoding="utf-8") as f:
        for line in list:
            f.write(str(line)+"\n")

def add_file(name,list):#写入一个文件，以列表传入
    with open(name,"a",encoding="utf-8") as f:
        for line in list:
            f.write(str(line)+"\n")
            
def load_file(name):#加载文件，每行一个元素，以列表返回
    l=[]
    with open(name,"r",encoding="latin-1") as f:
        for line in f:
            li=line.strip()
            l.append(li)
    return l
import datetime
 
weight = []
weight2 = []
wd = []

# def get_dataset(lis,graph,emap):
    # output = []
    # t = ''
    # d = ''
    # v1 = ''
    # v2 = ''
    # p = ''
    # info = ''
    # gap = 300
    # T = 1440
    # currentT = 0
    # print(datetime.datetime.now(),'start')
    # counter = 0
    # for l in lis:
        # counter += 1
        # items = l.split(',')
        # e = items[0]+','+items[1]
        # if e not in emap:
            # continue
        # t = int(items[2])
        # d = int(items[3])
        # if d == 0:
            # d = 1
        # wd.append(d)
        # info = int(items[4])
        # bytes = info/d
        # w = 0
        # savet = t//gap
        # for pos in range(d):
            # nowt = (t+pos)//gap
            # w += bytes
            # if nowt >= T:
                # break
            # if savet < nowt:
                # graph[savet][emap[e]] += w
                # w = 0
                # savet = nowt
        # if nowt < T:
            # graph[nowt][emap[e]] += w
        # if t//gap > currentT:
            # for epos in range(elen):
                # output.append(eset[epos]+','+str(currentT)+','+str(graph[currentT][epos]))
                # if graph[currentT][epos] != 0:
                    # weight.append(graph[currentT][epos])
                # weight2.append(graph[currentT][epos])
            # graph[currentT] = None
            # if currentT % 120 == 119:
                # add_file('NetflowV155252E378373T1440-2.txt',output)
                # output=[]
                # print('save'+str(currentT))
            # currentT = t//gap
        # #elif t//gap < currentT:
        # #    print('error2')
        # if counter % 1000000 == 0:
            # print(datetime.datetime.now(),t)
        # #    exit(0)
    # t = t//gap
    # for epos in range(elen):
        # output.append(eset[epos]+','+str(currentT)+','+str(graph[currentT][epos]))
        # if graph[currentT][epos] != 0:
            # weight.append(graph[currentT][epos])
        # weight2.append(graph[currentT][epos])
    # add_file('NetflowV155252E378373T1440-2.txt',output)
    # print('save'+str(currentT))
    
    # w20 = np.percentile(weight,20); 
    # w40 = np.percentile(weight,40); 
    # w60 = np.percentile(weight,60); 
    # w80 = np.percentile(weight,80); 
    # print(w20,w40,w60,w80) #168.0 833.9527490549174 4068.9011864055246 19091.987642674176

    # w20 = np.percentile(weight2,20); 
    # w40 = np.percentile(weight2,40); 
    # w60 = np.percentile(weight2,60); 
    # w80 = np.percentile(weight2,80); 
    # print(w20,w40,w60,w80) # 0 0 0 0

    # w20 = np.percentile(wd,20); 
    # w40 = np.percentile(wd,40); 
    # w60 = np.percentile(wd,60); 
    # w80 = np.percentile(wd,80);
    # avg = np.average(wd);
    # print(w20,w40,w60,w80,avg) #1.0 1.0 2.0 62.0 2020.3599334060086
    
    # del lis
    # import gc
    # gc.collect()


# def update_data(lis):
    # print('start')
    # counter = 0
    # a0 = a1 = a2 = a3 = a4 = a5 = 0
    # for l in lis:
        # items = l.split(',')
        # et = items[0]+','+items[1]+','+items[2]
        # w = items[3]
        # if w == '0':
            # l = '-1'
            # a0+=1
        # else:
            # w = float(items[3])
            # if w < 4096:# 4KB
                # l = '1'
                # a1+=1
            # elif w < 8192:# 8KB 
                # l = '2'
                # a2+=1
            # elif w < 12288:# 12KB 
                # l = '3'
                # a3+=1
            # elif w < 16384:# 16KB 
                # l = '4'
                # a4+=1
            # else: 
                # l = '5'
                # a5+=1
        # lis[counter] = et+','+l
        # counter += 1
        # if counter % 532986 == 0:
            # print(datetime.datetime.now(),counter//532986)
    # print(a0, a1, a2 , a3 ,a4,a5) # 130098377 14067865 2697080 1030310 614304 4992032
    # return lis


def get_edge(lis,eset,num):
    #output = []
    t = ''
    d = ''
    #v1 = ''
    #v2 = ''
    #p = ''
    #info = ''
    counter=0
    vset=set()
    for l in lis:
        counter += 1
        items = l.split(',')
        d = int(items[3])
        if d == 0:
            continue
        e = items[0]+','+items[1]
        if e not in eset:
            eset[e] = {num}
        else:
            eset[e].add(num)
        if counter % 1000000 == 0:
            print(datetime.datetime.now(),counter)
    #edgeN = len(eset)
    #print(len(vset),edgeN)
    del lis
    import gc
    gc.collect()
    #eset = list(eset)
    #return eset,output

def first(lis,nset,eset,start,startT,endT,number,counter):
    output = []
    t = ''
    d = ''
    v1 = ''
    v2 = ''
    p = ''
    info = ''
    for l in lis:
        items = l.split(',')
        #if t == '':
        t,d,v1,v2,info = int(items[0])-startT,items[1],items[2],items[3],int(items[9])+int(items[10])
        #if endT < int(t):
        #    endT = int(t)
        if v1 not in nset:
            nset[v1] = counter
            counter += 1
        if v2 not in nset:
            nset[v2] = counter
            counter += 1
        #if start == True:
        #    continue
        output.append(str(nset[v1])+','+str(nset[v2])+','+str(t)+','+str(d)+','+str(info))
        
    #lis = []
    #flag = True
    #for l in output:
        #n1 = l[2]
        #n2 = l[3]
        #t = int(l[0]) - startT
        #d = int(l[1])
        
        #if (n1,n2) not in eset:
        #	eset[(n1,n2)] = {number}
        #else:
        #	eset[(n1,n2)].add(number)
        #if d == 0:
        #    continue
        #lis.append(str(n1)+','+str(n2)+','+str(t)+','+str(d)+','+str(l[4]))
        #if flag == True:
            #print(lis)
            #flag = False
    #output = []
    return output,endT
    
#only used for generating files:
#netflow_day-%02d-o.txt necessary properties from original data
#NETnode.txt nodes of graph
#NETedge.txt edges of graph
if __name__ == "__main__":
    end = 8
    for i in range(3,end):
        filename.append("netflow_day-%02d" % i)
    
    eset = {}
    nset = {}
    start = True
    startT = 172800 
    endT = 604799
    #counter = 0
    emap = {}
    ecounter = 0
    #vset=set()
    for e in eset:
    #    vs = e.split(',')
    #    vset.add(vs[0])
    #    vset.add(vs[1])
        emap[e] = ecounter
        ecounter += 1
    #print(len(vset)) 
    #elen = len(eset) #359450
    for f in filename:
        print(f)
        number = int(f[-1])
        lis = load_file(f)
        output,endT = first(lis,nset,eset,start,startT,endT,number,counter) #get necessary property
        
        #lis=[]
        #nodes = []
        #for name,id in nset.items():
        #    nodes.append(name+','+str(id))
        #counter = len(nodes)
        #add_file('NETnode.txt',nodes)
        
        #nodes = []
        #if start == True:
        #    start = False
        #    continue
        #print(startT,endT)
        
        #get_edge(lis,eset,number)
        
        
        write_file(f+'-o',output)
        #output = []
    #edges = []
    #counter = 0
    #for name,id in eset.items():
    #	if len(id) >= 3:
    #		counter += 1
    #		edges.append(name)
    #write_file('NETedge.txt',edges)
    #print(counter,startT,endT)  #E = 378373
    
    
        