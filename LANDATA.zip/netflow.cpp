﻿// netflow.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <stdio.h>
#include<iostream>
#include<cctype>
#include<cstring>
#include<algorithm>
#include<vector>
#include<queue>
#include<exception>
#include<unordered_map>
#include<string>
#include<fstream>
#include<stack>
#include<map>
#include<set>
#include<ctime>
#include<cstdlib>
#include<Windows.h>
#include<psapi.h>
#include<iomanip>
#include <memory>
#include <cassert>
#include <chrono>
using namespace std;
double calculate_quantile(const std::vector<double>& data, double quantile) {
	if (quantile < 0.0 || quantile > 1.0) {
		throw std::out_of_range("Quantile must be between 0.0 and 1.0");
	}

	size_t index = static_cast<size_t>((data.size() - 1) * quantile);
	std::vector<double> sorted_data = data;
	std::sort(sorted_data.begin(), sorted_data.end());

	if (index == data.size() - 1) {
		return sorted_data[index];
	}
	else {
		double lower = sorted_data[index];
		double upper = sorted_data[index + 1];
		return lower + (upper - lower) * (quantile - static_cast<int>(quantile));
	}
}
template<class T1, class T2>
struct hash<pair<T1, T2>> {
	size_t operator()(const pair<T1, T2>& p) const {
		auto h1 = hash<T1>{}(p.first);
		auto h2 = hash<T2>{}(p.second);
		return h1 ^ h2; 
	}
}; 

template<class T1, class T2>
struct equal_to<pair<T1, T2>> {
	bool operator()(const pair<T1, T2>& lhs, const pair<T1, T2>& rhs) const {
		return lhs.first == rhs.first && lhs.second == rhs.second;
	}
};
void readfile() {
	
	unordered_map<pair<int, int>, int> emap;
	vector<string> elist;
	FILE* em;
	fopen_s(&em,"NETedge.txt", "r+");
	if (!em) exit(0);
	char line[1000];
	int counter = 0;
	try{
		while (fgets(line, 1000, em)) {
			if (strlen(line) == 0) continue;
			int v1 = (int)(find(line, line + 1000, ',') - line);
			int v2 = (int)(find(line + v1 + 1, line + 1000, ',') - line);
			int node1 = atoi(line);
			int node2 = atoi(line + v1 + 1);
			emap[pair<int, int>(node1, node2)] = counter++;
			elist.emplace_back(to_string(node1)+","+to_string(node2));
		}
	}
	catch (exception& e) {
		cout << "load error" << endl;
	}
	double** graph = new double*[1440];
	for (int i = 0; i < 1440; i++) {
		graph[i] = new double[counter];
	}
	cout << counter << endl;
	int ct = 0;
	auto mapEnd = emap.end();
	int gap = 300;
	int T = 1440;
	int currentT = 0;
	vector<string> output;
	vector<double> w1, w2, wd;
	const char* files[] = {"netflow_day-03-o","netflow_day-04-o" ,"netflow_day-05-o" ,"netflow_day-06-o" ,"netflow_day-07-o" };
	int t;
	bool flag = false;
	int g = 172800;
	for (auto f : files) {
		cout << f << endl;
		FILE* file;
		fopen_s(&file,f, "r+");
		if (!file) exit(0);
		char line[1000];
		int node1;
		int node2;
		int dur;
		try {
			while (fgets(line, 1000, file)) {
				if (strlen(line) == 0) continue;
				int v1p = (int)(find(line, line + 1000, ',') - line);
				int v2p = (int)(find(line + v1p + 1, line + 1000, ',') - line);
				int tp = (int)(find(line + v2p + 1, line + 1000, ',') - line);
				int dp = (int)(find(line + tp + 1, line + 1000, ',') - line);
				int info = (int)(find(line + dp + 1, line + 1000, ',') - line);
				node1 = atoi(line);
				node2 = atoi(line + v1p + 1);
				ct++;
				pair<int, int> e = pair<int, int>(node1, node2);
				if (emap.find(e) == mapEnd) {
					continue;
				}
				t = atoi(line + v2p + 1);
				if (flag) {
					t -= g;
				}
				dur = atoi(line + tp + 1);
				dur = dur == 0 ? 1 : dur;
				wd.emplace_back(dur);
				int weight = atoi(line + dp + 1);
				double bytes = weight * 1.0 / dur;
				double w = 0;
				int	savet = t / gap;
				int nowt;
				for (auto pos = 0; pos < dur; pos++) {
					nowt = (t + pos) / gap;
					w += bytes;
					if (nowt >= T) break;
					if (savet < nowt) {
						graph[savet][emap[e]] += w;
						w = 0;
						savet = nowt;
					}
				}
				if (nowt < T) {
					graph[nowt][emap[e]] += w;
				}
				if (t / gap > currentT) {
					for (auto epos = 0; epos < counter; epos++) {
						output.emplace_back(elist[epos] + ',' + to_string(currentT) + ',' + to_string(graph[currentT][epos]));
						if (graph[currentT][epos] != 0) {
							w1.emplace_back(graph[currentT][epos]);
						}
						w2.emplace_back(graph[currentT][epos]);
					}
					delete[] graph[currentT];
					if (currentT % 120 == 119)
						cout << "save" + to_string(currentT) << endl;
					currentT = t / gap;
				}
				if (ct % 10000000 == 0) {
					time_t now = time(0);
					struct tm dt;
					localtime_s(&dt,&now);
					cout << dt.tm_hour << ":"
						<< dt.tm_min << ":"
						<< dt.tm_sec << "  " << t << endl;
				}
			}
			
		}
		catch (exception& e) {
			cout << "load error" << endl;
		}
		flag = true;
	}
	t = t / gap;
	for (auto epos = 0; epos < counter; epos++) {
		output.emplace_back(elist[epos] + ',' + to_string(currentT) + ',' + to_string(graph[currentT][epos]));
		if (graph[currentT][epos] != 0) {
			w1.emplace_back(graph[currentT][epos]);
		}
		w2.emplace_back(graph[currentT][epos]);
	}
	delete[] graph[currentT];
	cout << "save" + to_string(currentT) << endl;
	currentT = t / gap;

	auto w20 = calculate_quantile(w1, 0.20);
	auto w40 = calculate_quantile(w1, 0.40);
	auto w60 = calculate_quantile(w1, 0.60);
	auto w80 = calculate_quantile(w1, 0.80);
	cout << w20 << " " << w40 << " " << w60 << " " << w80 << endl; //227.691 768 3344 15214

	w20 = calculate_quantile(w2, 0.20);
	w40 = calculate_quantile(w2, 0.40);
	w60 = calculate_quantile(w2, 0.60);
	w80 = calculate_quantile(w2, 0.80);
	cout << w20 << " " << w40 << " " << w60 << " " << w80 << endl; //0 0 0 43.7671

	w20 = calculate_quantile(wd, 0.20);
	w40 = calculate_quantile(wd, 0.40);
	w60 = calculate_quantile(wd, 0.60);
	w80 = calculate_quantile(wd, 0.80);
	auto avg = calculate_quantile(wd, 0.50);
	cout << w20 << " " << w40 << " " << w60 << " " << w80 << " " << avg << endl; //1 1 1 9 1



	FILE* out;
	freopen_s(&out,"dataset.txt", "a", stdout); ios::sync_with_stdio(false);
	for (auto l : output) {
		cout << l << endl;
	}
	fclose(stdout);
	delete[] graph;
}


void update() {
	vector<string> output;
	int t;
	FILE* file;
	fopen_s(&file, "dataset.txt", "r+");
	if (!file) exit(0);
	char line[1000];
	int node1;
	int node2;
	double w;
	int ct = 0;
	try {
		int a0, a1, a2, a3, a4, a5;
		while (fgets(line, 1000, file)) {
			if (strlen(line) == 0) continue;
			int v1p = (int)(find(line, line + 1000, ',') - line);
			int v2p = (int)(find(line + v1p + 1, line + 1000, ',') - line);
			int tp = (int)(find(line + v2p + 1, line + 1000, ',') - line);
			int wp = (int)(find(line + tp + 1, line + 1000, ',') - line);
			
			node1 = atoi(line);
			node2 = atoi(line + v1p + 1);
			t = atoi(line + v2p + 1);
			w = atof(line + tp + 1);
			char l;
			if (w == 0) {
				l = '0'; a0 ++;
			}
			else if (w < 4096) {
				// 4KB
				l = '1';
				a1++;
			}
			else if (w < 8192) {
				// 8KB
				l = '2';
				a2++;
			}
			else if (w < 12288) {
				// 12KB
				l = '3';
				a3++;
			}
			else if (w < 16384) {
				// 16KB
				l = '4';
				a4++;
			}
			else {
				l = '5';
				a5++;
			}
			output.emplace_back(to_string(node1) + ',' + to_string(node2) + ',' + to_string(t) + ',' + l);
			ct++;
			if (ct % 1000000 == 0) {
				time_t now = time(0);
				struct tm dt;
				localtime_s(&dt, &now);
				cout << dt.tm_hour << ":"
					<< dt.tm_min << ":"
					<< dt.tm_sec << "  " << t << endl;
			}
		}
		cout << a0 << " " << a1 << " " << a2 << " " << a3 << " " << a4 << " " << a5 << endl;
	}
	catch (exception& e) {
		cout << "load error" << endl;
	}

	FILE* out;
	freopen_s(&out, "NetflowV155252E378373T1440.txt", "a", stdout); ios::sync_with_stdio(false);
	for (auto l : output) {
		cout << l << endl;
	}
	fclose(stdout);
}
int main()
{
	//readfile();
	update();
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
