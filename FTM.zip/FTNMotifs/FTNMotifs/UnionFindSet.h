#pragma once
#include "stdafx.h"
/*union-find set used for counting the number of connected component 
	and creating connected component
	use path compression and union by rank
*/
class UnionFindSet {
private:
		int* parent;
		int* depth;//the depth of subtree
		int size;
public:
	UnionFindSet(int size)
		:size(size){
		parent = DBG_NEW int[size];
		depth = DBG_NEW int[size];
		initialize();
	}
	~UnionFindSet() {
		delete[]parent;
		delete[]depth;
	}
	int find(int num);//find the root of the node whose position is num
	//union two trees where two nodes locate
	void unionfind(int a, int b);
	/*union two trees where two nodes locate
	return the old root of tree
	*/
	int newUnionVertexs(int a, int b);

	inline int getSize()const { return size; }

	int* getParent()const { return parent; }

	int* getDepth()const { return depth; }

	void initialize() {
		for (int i = 0; i < size; i++) {
			parent[i] = -1;
			depth[i] = 1;
		}
	}

	UnionFindSet(const UnionFindSet& ufset) {
		size = ufset.getSize();
		parent = DBG_NEW int[size];
		depth = DBG_NEW int[size];
		int* d = ufset.getDepth();
		int* p = ufset.getParent();
		for (int i = 0; i < size; ++i) {
			depth[i] = d[i];
			parent[i] = p[i];
		}
	}

	void print() {
		for (int i = 0; i < size; i++) {
			cout<<i<<"(p:"<<parent[i]<<
				",d:"<<depth[i]<<")"<<endl;
		}
	}
};