#include"TGraph.h"
#include"stdafx.h"

TGraph::TGraph(const TGraph& ances):
	startT(ances.startT), endT(ances.endT),
	nTimestamp(ances.nTimestamp),
	nNode(ances.nNode),nEdge(ances.nEdge),
	edge2ind(DBG_NEW map<Edge, int>(*ances.edge2ind)){
	edgeList = DBG_NEW Edge[nEdge];
	vertexToId = ances.vertexToId;
	ufset = DBG_NEW UnionFindSet(*ances.ufset);
	for (int i = 0; i < nEdge; i++) {
		edgeList[i] = ances.edgeList[i];
	}
}

#pragma region save temporal graph to index
//save all information from temporal graph
void TGraph::loadInformation(const char*& src, set<Edge>& origEdge, 
	vec(int)& u_arr,vec(int)& v_arr,
	vec(int)& t_arr,vec(Label)& w_arr) {
	u_arr.reserve(ALLOC_MEM);
	v_arr.reserve(ALLOC_MEM);
	t_arr.reserve(ALLOC_MEM);
	w_arr.reserve(ALLOC_MEM);//allocate the memory

	nNode = nEdge = 0;
	//unordered_map<int, bool> nodeHashmap;//hashmap for recording node id 
	unordered_map<int, int>::iterator iter;
	int nodeNum = 0;//node num
	int firstT = 0x7fffffff, lastT = -1;//set startT and endT
	int flagT = -1;//check the same time as the first input data
	int u, v, t;
	Label w;
	edge2ind = DBG_NEW map<Edge, int>();// map from an edge to its index in edgeT

	FILE* file;
	file = fopen(src, "r+");
	if (!file) exit(0);
	char line[LINE_LENGTH];
	CLEARALL(line, 0, LINE_LENGTH, char);
	unordered_map<int, int> tempVertexToId;
	int sep1, sep2, sep3;//separator pos
	long ind = 0;
	try {
		while (fgets(line, LINE_LENGTH, file)) {
			if (strlen(line) == 0) continue;
			sep1 = (int)(find(line, line + LINE_LENGTH, SEP_CHAR) - line);
			sep2 = (int)(find(line + sep1 + 1, line + LINE_LENGTH, SEP_CHAR) - line);
			sep3 = (int)(find(line + sep2 + 1, line + LINE_LENGTH, SEP_CHAR) - line);
			u = STR2INT(line);
			v = STR2INT(line + sep1 + 1);
			t = STR2INT(line + sep2 + 1);
			w = STR2INT(line + sep3 + 1);
			if (firstT > t)firstT = t;
			if (lastT < t)lastT = t;
			if (flagT == -1) flagT = t;
			if (flagT == t) {//save static graph structure
				iter = tempVertexToId.find(u);
				if (iter == tempVertexToId.end()) {
					tempVertexToId[u] = nodeNum++;
				}//save the node id into hashmap
				iter = tempVertexToId.find(v);
				if (iter == tempVertexToId.end()) {
					tempVertexToId[v] = nodeNum++;
				}//save the map of name to id and id to name
				Edge e(u, v);
				//edgeSet->insert(e1);
				set<Edge>::iterator iter = origEdge.find(e);
				if (iter == origEdge.end()) {
					(*edge2ind)[e] = ind;
					e.id = ind;
					++ind;
					origEdge.insert(e);//save the edge of graph
				}
				else continue;//multiple edges
			}
			u_arr.emplace_back(u);
			v_arr.emplace_back(v);
			t_arr.emplace_back(t);
			w_arr.emplace_back(w);
		}
		fclose(file);
		this->startT = firstT;
		this->endT = lastT;
		this->nNode = nodeNum;
		this->ufset = DBG_NEW UnionFindSet(nodeNum);
		this->nEdge = origEdge.size();
		this->nTimestamp = lastT - firstT + 1;
		this->edgeList = DBG_NEW Edge[nEdge];
		for (set<Edge>::iterator iter = origEdge.begin();
			iter != origEdge.end(); ++iter) {
			edgeList[iter->id] = *iter;
		}
	}
	catch (exception& e) {
		Util::printError(e);
		cout << "load error" << endl;
	}
}
//save all information from temporal graph with interval [fixedS, fixedE]
void TGraph::loadInformation(const char*& src, set<Edge>& origEdge,
	vec(int)& u_arr, vec(int)& v_arr,
	vec(int)& t_arr, vec(Label)& w_arr,
	int fixedS, int fixedE) {
	
	u_arr.reserve(ALLOC_MEM);
	v_arr.reserve(ALLOC_MEM);
	t_arr.reserve(ALLOC_MEM);
	w_arr.reserve(ALLOC_MEM);//allocate the memory

	nNode = nEdge = 0;
	unordered_map<int, int>::iterator iter;
	int nodeNum = 0;//node num
	int flagT = -1;//check the same time as the first input data
	int u, v, t;
	Label w;

	edge2ind = DBG_NEW map<Edge, int>();// map from an edge to its index in edgeT

	FILE* file;
	file = fopen(src, "r+");
	if (!file) exit(0);
	char line[LINE_LENGTH];
	CLEARALL(line,0, LINE_LENGTH, char);
	int sep1, sep2, sep3;//separator pos
	unordered_map<int, int> tempVertexToId;
	long ind = 0;
	if (fixedE == -1) fixedE = 0x7fffffff;
	int tempEndT = -1;
	try {
		while (fgets(line, LINE_LENGTH, file)) {
			if (strlen(line) == 0) continue;
			sep1 = (int)(find(line, line + LINE_LENGTH, SEP_CHAR) - line);
			sep2 = (int)(find(line + sep1 + 1, line + LINE_LENGTH, SEP_CHAR) - line);
			sep3 = (int)(find(line + sep2 + 1, line + LINE_LENGTH, SEP_CHAR) - line);
			u = STR2INT(line);
			v = STR2INT(line + sep1 + 1);
			t = STR2INT(line + sep2 + 1);
			w = STR2INT(line + sep3 + 1);
			if (flagT == -1) flagT = t;
			if (flagT == t) {//save static graph structure
				iter = tempVertexToId.find(u);
				if (iter == tempVertexToId.end()) {
					tempVertexToId[u] = nodeNum++;
				}//save the node id into hashmap
				iter = tempVertexToId.find(v);
				if (iter == tempVertexToId.end()) {
					tempVertexToId[v] = nodeNum++;
				}//save the map of name to id and id to name
				Edge e(u, v);
				set<Edge>::iterator iter = origEdge.find(e);
				if (iter == origEdge.end()) {
					(*edge2ind)[e] = ind;
					e.id = ind;
					++ind;
					origEdge.insert(e);//save the edge of graph
				}
				else continue;//multiple edges
			}
			if (t >= fixedS&&t <= fixedE) {
				if (t > tempEndT)tempEndT = t;
				u_arr.emplace_back(u);
				v_arr.emplace_back(v);
				t_arr.emplace_back(t);
				w_arr.emplace_back(w);
			}
		}
			
		fclose(file);
		this->startT = fixedS;
		this->endT = tempEndT;
		this->nNode = nodeNum;
		this->ufset = DBG_NEW UnionFindSet(nodeNum);
		this->nEdge = origEdge.size();
		this->nTimestamp = fixedE - fixedS + 1;
		this->edgeList = DBG_NEW Edge[nEdge];
		set<Edge>::iterator iterEnd = origEdge.end();
		for (set<Edge>::iterator iter = origEdge.begin();
			iter != iterEnd; ++iter) {
			edgeList[iter->id] = *iter;
		}
	}
	catch (exception& e) {
		Util::printError(e);
		cout << "load error" << endl;
	}
}
#pragma endregion

#pragma region key static algorithms
/*FTM*/
void TGraph::getAllMotifsM2(int k, vec(TNMotif*)*& result,
	/*i2bHMap& fixLabel, bool isEdgeTypeFixed,*/ long long& motifNumber,
	int choiceStartT, int choiceEndT) {
#pragma region initialize
	i2iHMap tempVertex2Pos;//map the vertex's id to the position in union-find set
	/*map the root's position in union-find set to the position
	of the connected component in the component list*/
	i2iHMap root2Comp;
	vec(TempMotif*) tempMotifList;//temporary component list
	SAVEINFO_Vec* selectedEdge =
		DBG_NEW SAVEINFO_Vec[maxIntervalLength];
	vec(int) saveMotifPos;//record the position of motifs which need to be saved
	/*record the position of motifs which
	need to combine with other motifs*/
	vec(int) combineMotifPos;
	UnionFindSet* tempUfset;//union find set
	int vertexNum;//the number of vertexs
	int realMotifNum;//the number of generated connected component
	SAVEINFO_VIter iterEnd, iterStart;//iterator for selectedEdge
	veciter(TempMotif*) listEnd;//iterator for tempMotifList
	int lastTime = choiceEndT - k + 1;//last start time 
	int edgeEndT;//record the currently considering end time of edges
	int selectedNum;//the number of selected edges
	long long maxSelect = 0;//the max number of selected edges
	long long selectedSum = 0;//the sum of selected edges number
	int Te;//the end time of interval
	clock_t begin;
	long long allSmt=0, maxSmt=0,smt;
#pragma endregion
	for (int Ts = choiceStartT; Ts <= lastTime; Ts++) {//O(T)
		// select edges which keep fixed in [Ts,Ts+k-1]
		begin = clock(); 
		selectedNum = 0;
		Te = Ts + k - 1;
		getCandidate(Ts, Te,
			selectedEdge, selectedNum/*,
			fixLabel, isEdgeTypeFixed*/);//O(E)
		//initalize for every row
		maxSelect = max(maxSelect, selectedNum);
		selectedSum += selectedNum;
		tempUfset = DBG_NEW UnionFindSet((int)((selectedNum << 1) + 1));
		tempVertex2Pos.clear();
		root2Comp.clear();
		vertexNum = 0;
		realMotifNum = 0;
		edgeEndT = choiceEndT;
		Test::compr += clock() - begin;

		//Test S(m,T)
		if (maxIntervalLength <= choiceEndT - Te) smt = 0;
		else smt = selectedEdge[choiceEndT - Te].size();
		maxSmt = max(maxSmt, smt);
		allSmt += smt;
		
		//traverse every edge in selectedEdges
		for (int tempT = choiceEndT - Te; tempT >= 0; tempT--, edgeEndT--) {//O(T)
			if (tempT >= maxIntervalLength) continue;
			iterStart = selectedEdge[tempT].begin();
			iterEnd = selectedEdge[tempT].end();
			if (iterStart == iterEnd) continue;
			getMotifInOneIntvM2(iterStart, iterEnd,
				tempVertex2Pos, tempUfset, vertexNum,
				combineMotifPos, realMotifNum, root2Comp, tempMotifList,
				saveMotifPos, Ts, edgeEndT,
				result, resultPos(Ts, edgeEndT, startT, endT, k), motifNumber);
			selectedEdge[tempT].clear();
		}
		//release
		delete tempUfset;
		listEnd = tempMotifList.end();
		for (veciter(TempMotif*) listIter = tempMotifList.begin();
			listIter != listEnd; ++listIter) {
			if (*listIter != NULL)
				delete *listIter;
		}
		tempMotifList.clear();
	}
	delete[] selectedEdge;
	cout << SELECT_EDGE << maxSelect << endl;
	cout << MEAN_SELECT_EDGE << selectedSum / (lastTime - choiceStartT + 1) << endl;
	cout << "maxSmT: " << maxSmt<< " averSmT: "<< allSmt/(lastTime - choiceStartT + 1) << endl;
}
#pragma endregion

#pragma region key incremental algorithms
/*DFTM (row number<=T-k+1)*/
void TGraph::getAllMotifsDynamicGM2(int k, 
	vec(TNMotif*)*& newResult, int oriEndT,
	/*i2bHMap& fixLabel, bool isEdgeTypeFixed,*/ long long& motifNumber) {

#pragma region intialization
#pragma region temporary structure
	/*map the vertex's id to the position in union-find set*/
	i2iHMap tempVertex2Pos;
	/*map the root's position in union-find set to the position
	of the connected component in the component list*/
	i2iHMap root2Comp;
	vec(TempMotif*) tempMotifList;//temporary component list
	SAVEINFO_Vec* selectedEdge =
		DBG_NEW SAVEINFO_Vec[maxIntervalLength];
	/*record the position of motifs which need to be saved*/
	vec(int) saveMotifPos;
	/*record the position of motifs which
	need to combine with other motifs*/
	vec(int) combineMotifPos;
	UnionFindSet* tempUfset;//union find set
#pragma endregion 
#pragma region temporary variable
	int vertexNum;//the number of vertexs
	int realMotifNum;//the number of generated connected component
	SAVEINFO_VIter iterEnd, iterStart;//iterator for selectedEdge
	veciter(TempMotif*) listEnd;//iterator for tempMotifList
	int lastTime = oriEndT - k + 1;//last start time 
	int edgeEndT;//record the currently considering end time of edges
	int selectedNum;//the number of selected edges
	veciter(TNMotif*) resultEnd;
	int pos;
	int Te, intvE;//temporary end time
#pragma endregion 
#pragma endregion 

	//traverse all possible intervals' start time
	for (int Ts = startT; Ts <= lastTime; Ts++) {//O(T)
#pragma region select edges which keep fixed in [Ts,Ts+k-1]
		selectedNum = 0;
		Te = Ts + k - 1;
		intvE = oriEndT;
		pos = resultPos(Ts, intvE, startT, endT, k);
		getCandidateForDynamicGCM2(Ts, intvE,
			selectedEdge, selectedNum,
			oriEndT, /*fixLabel, isEdgeTypeFixed,*/ k,
			newResult[pos]);//O(E)
		newResult[pos].clear();
#pragma endregion
#pragma region temporary structures or variables are initalize for every start time
		tempUfset = DBG_NEW UnionFindSet
		((int)((selectedNum << 1) + 1));
		root2Comp.clear();
		tempVertex2Pos.clear();
		vertexNum = 0;
		realMotifNum = 0;
		edgeEndT = endT;
#pragma endregion
		//traverse every edge in selectedEdges
		int startPos = endT - oriEndT;
		for (int tempT = startPos; tempT >= 0; tempT--, edgeEndT--) {//O(Es)
			if (tempT >= maxIntervalLength) continue;
			iterStart = selectedEdge[tempT].begin();
			iterEnd = selectedEdge[tempT].end();
			if (iterStart == iterEnd) continue;
			
			getMotifInOneIntvM2(iterStart, iterEnd,
				tempVertex2Pos, tempUfset, vertexNum,
				combineMotifPos, realMotifNum, root2Comp, tempMotifList,
				saveMotifPos, Ts, edgeEndT,
				newResult, resultPos(Ts, edgeEndT, startT, endT, k), motifNumber);
			selectedEdge[tempT].clear();
		}
		//release
		delete tempUfset;
		listEnd = tempMotifList.end();
		for (auto listIter = tempMotifList.begin();
			listIter != listEnd; ++listIter) {
			if (*listIter != NULL)
				delete *listIter;
		}
		tempMotifList.clear();
	}
	delete[] selectedEdge;
}
#pragma endregion

#pragma region process of FTM

#pragma region FTM step 2 and step 3
/*get motifs in one interval*/
void TGraph::getMotifInOneIntvM2(SAVEINFO_VIter& iterStart, SAVEINFO_VIter& iterEnd,
	i2iHMap& tempVertex2Pos, UnionFindSet*& tempUfset, int& vertexNum,
	vec(int)& combineMotifPos, int& realMotifNum,
	i2iHMap& root2Comp, vec(TempMotif*)& tempMotifList,
	vec(int)& saveMotifPos, int motifStartT, int motifEndT,
	vec(TNMotif*)*& result, int pos, long long& motifNumber) {
	clock_t begin;
	begin = clock();
	//update disjoint set
	insertIntoDisjointSet(iterStart, iterEnd,
		tempVertex2Pos, tempUfset, vertexNum,
		combineMotifPos);//O(cEs)
	//combine generated motif
	combineComponents(tempMotifList,
		tempVertex2Pos, tempUfset, root2Comp,
		/*motifListSize,*/ realMotifNum,
		combineMotifPos);//O(nEs')
	/*insert new edges into motif or generate new motif,
	new considered edges are in selectedEdge[iterStart,iter-1]
	*/
	updateNewEdgeInfo(iterStart, iterEnd,
		tempMotifList, tempVertex2Pos, tempUfset,
		root2Comp, /*motifListSize,*/ realMotifNum, saveMotifPos, motifStartT);//O(��Es)
	Test::gm += clock()-begin;
	
	begin = clock();
	//save motif O(nEs')
	saveResult(saveMotifPos, tempMotifList,
		result[pos], motifStartT,
		motifEndT, motifNumber);
	Test::gne += clock() - begin;
}

/*insert the edge's two endpoints into the union-find set (maintain connectivity)*/
void TGraph::insertIntoDisjointSet(SAVEINFO_VIter& infoBegin,
	SAVEINFO_VIter& infoEnd, i2iHMap& vertex2Pos, UnionFindSet*& ufset, int&vertexNum,
	vec(int)& combineMotifPos) {
	//use disjoint set to maintain connectivity
	Edge* temp;
	int motifPos;
	i2iHMap_Iter vertexIt;
	int sId, tId, vertex;//vertexs'id in the union-find set
	for (SAVEINFO_VIter iter = infoBegin;
		iter != infoEnd; ++iter) {
		temp = &edgeList[iter->edgeId];//new inserted edge
		vertex = temp->s;
		vertexIt = vertex2Pos.find(vertex);//O(1)
		if (vertexIt == vertex2Pos.end()) {
			sId = vertexNum;
			vertex2Pos[vertex] = vertexNum++;
		}
		else sId = vertexIt->second;
		vertex = temp->t;
		vertexIt = vertex2Pos.find(vertex);//O(1)
		if (vertexIt == vertex2Pos.end()) {
			tId = vertexNum;
			vertex2Pos[vertex] = vertexNum++;
		}
		else tId = vertexIt->second;

		/*union-find operation means that sId and tId are connected*/
		motifPos = ufset->newUnionVertexs(sId, tId);
		if (motifPos != -1)
			combineMotifPos.push_back(motifPos);
	}
}

/*combine components which are connected (generateMaxTM case 3)*/
void TGraph::combineComponents(vec(TempMotif*)& motifList,
	i2iHMap& edgeMap, UnionFindSet*& ufset,
	i2iHMap& rootMap, /*int& motifListSize,*/int& realMotifNum,
	vec(int)& combineMotifPos) {
#pragma region initialize
	int oldRoot, newRoot;//the original/current root in union-find set
	int nowPos = 0;//motif's new position in motifList
	TempMotif* tempMotif, *combineMotif;//move tempMotif's edges to combineMotif
	vec(TEdge)* tempEdges;//edges of tempMotif
#pragma region temporary iterator
	veciter(int) listEnd = combineMotifPos.end();//motifList's iterator
	veciter(TEdge) edgeEnd;//tempEdges' iterator
	i2iHMap_Iter combineIter, mapIter;//rootMap's iterator
	int combinePos;//the position of combined motif
#pragma endregion
#pragma endregion
#pragma region combination
	for (auto listIter = combineMotifPos.begin();
		listIter != listEnd; ++listIter) {//O(n)
		combineIter = rootMap.find(*listIter);//motif position
		if (combineIter != rootMap.end()) {//motif is combined to another motif
			combinePos = combineIter->second;
			tempMotif = motifList[combinePos];
			oldRoot = tempMotif->root;
			newRoot = ufset->find(oldRoot);
			rootMap.erase(oldRoot);
			mapIter = rootMap.find(newRoot);
			if (mapIter == rootMap.end()) {//new edge will be inserted
				tempMotif->root = newRoot;
				rootMap[newRoot] = combinePos;
				continue;
			}
			tempEdges = &tempMotif->edges;
			combineMotif = motifList[mapIter->second];
			edgeEnd = tempEdges->end();
			//insert edges of tempMotif into combineMotif
			for (auto edgeIter = tempEdges->begin();
				edgeIter != edgeEnd; ++edgeIter) {//O(Es')
				combineMotif->edges.emplace_back(*edgeIter);
			}
			if (combineMotif->startT < tempMotif->startT) {
				combineMotif->startT = tempMotif->startT;
			}
			delete tempMotif;//tempMotif need to be deleted
			motifList[combinePos] = NULL;//this position will be deleted
			realMotifNum--;
		}
	}
#pragma endregion
	combineMotifPos.clear();
}

/*insert edge into generated motif or generate new motif and check left expandable
			generateMaxTM and generateExpTM*/
void TGraph::updateNewEdgeInfo(
	SAVEINFO_VIter& infoBegin, SAVEINFO_VIter& infoEnd,
	vec(TempMotif*)& motifList,
	i2iHMap& edgeMap, UnionFindSet*& ufset,
	i2iHMap& rootMap, /*int& motifListSize,*/ int& realMotifNum,
	vec(int)& saveMotifPos, int startTime) {

#pragma region initialize
	i2bHMap hasSaved;//means whether the motif has been saved 
	i2iHMap_Iter mapIter;//rootMap's iterator 
	int root;//the root of one vertex in the union-find set
	int id;//the edge's id
	int startT;//the edge's start time of its interval
	int label;//the edge's label
	int motifListPos;//motif's position in motifList
	/*the motif which has already generated/will generate*/
	TempMotif* generatedMotif, *newMotif;
	int motifListSize;//size of motifList
#pragma endregion

	for (SAVEINFO_VIter infoIter = infoBegin;
		infoIter != infoEnd; ++infoIter) {//new inserted edges O(��Es)
										  //id = selectedIter->first;
		id = infoIter->edgeId;//edge's id
		/*the root of the edge's vertex in the union-find set*/
		root = ufset->find(edgeMap[edgeList[id].s]);

		mapIter = rootMap.find(root);//check which motif the edge belongs to 
		startT = infoIter->startT;//start time of the edge
		label = infoIter->label; //label of the edge

		if (mapIter == rootMap.end()) {//generateMaxTM case 1
			newMotif = DBG_NEW TempMotif(startT, root);
			//newMotif->edges = DBG_NEW vector<TEdge>();
			newMotif->edges.emplace_back(id, label);
			motifListSize = (int)motifList.size();
			motifList.emplace_back(newMotif);
			rootMap[root] = motifListSize;//update root2Comp

			//generateExpTM
			if (startT == startTime) {//left unexpandable
				saveMotifPos.emplace_back(motifListSize);
				hasSaved[motifListSize] = true;
			}

			realMotifNum++;
		}
		else {//generateMaxTM case 2
			motifListPos = mapIter->second;
			generatedMotif = motifList[motifListPos];
			generatedMotif->edges.emplace_back(id, label);
			if (generatedMotif->startT < startT) {
				generatedMotif->startT = startT;
			}
			/*
			check whether this motif has already
			been inserted into save list
			*/
			if (hasSaved.find(motifListPos) == hasSaved.end()) {
				//generateExpTM
				if (generatedMotif->startT == startTime) {//left unexpandable
					saveMotifPos.emplace_back(motifListPos);
					hasSaved[motifListPos] = true;
				}
			}
		}
	}
}
/*save generated motifs into result*/
void TGraph::saveResult(vec(int)&saveMotifPos,
	vec(TempMotif*)& motifList,
	vec(TNMotif*)& result, int motifStartT, int motifEndT,
	long long& motifNumber) {
	veciter(int) saveMotifEnd = saveMotifPos.end();
	TNMotif* motif;
	//O(n) number of motif need to be saved
	for (auto saveMotifIter = saveMotifPos.begin();
		saveMotifIter != saveMotifEnd; ++saveMotifIter) {
		motif = DBG_NEW TNMotif(motifStartT, motifEndT);
		motif->setMotifEdge(motifList[*saveMotifIter]->edges);
		result.emplace_back(motif);
	}
	motifNumber += saveMotifPos.size();
	saveMotifPos.clear();
}
#pragma endregion

#pragma endregion

/*print motif*/
void TGraph::printMotif(TNMotif* motif) {
	vec(TEdge)* motifEdge = motif->getMotifEdge();
	veciter(TEdge) listEnd = motifEdge->end();
	Edge *edge;
	for (auto iter = motifEdge->begin();
		iter != listEnd; ++iter) {
		edge = &edgeList[iter->id];
		cout << edge->s << "," << edge->t <<
			"," << iter->label <<endl;
	}
}

