#include "IntervalTree.h"
#include "stdafx.h"

#pragma region maintain interval tree
//rotate right
void IntervalTree::rRotate(IntervalTNode* &mynode) {
	IntervalTNode* node = mynode;
	if (!node)return;
	IntervalTNode* temp = node->left;
	if (!temp)return;
	node->left = temp->right;//right subtree of temp put in root->left
	if (temp->right)temp->right->parent = node;//the right node!=NULL
	temp->right = node;//root put in right subtree of temp
	if (node->parent&&node->parent->left == node) {
		node->parent->left = temp;
	}
	else if (node->parent) {
		node->parent->right = temp;
	}
	temp->parent = node->parent;
	node->parent = temp;
	//update tMax and tMin
	temp->tMax = node->tMax;
	//temp->tMin = node->tMin;
	update(node);
}

//rotate left
void IntervalTree::lRotate(IntervalTNode* &mynode) {
	IntervalTNode* node = mynode;
	if (!node)return;
	IntervalTNode* temp = node->right;
	if (!temp)return;
	node->right = temp->left;//left subtree of temp put in root->right
	if (temp->left)temp->left->parent = node;//the right node!=NULL
	temp->left = node;//root put in left subtree of temp
	if (node->parent&&node->parent->left == node) {
		node->parent->left = temp;
	}
	else if (node->parent) {
		node->parent->right = temp;
	}
	temp->parent = node->parent;
	node->parent = temp;
	//update tMax
	temp->tMax = node->tMax;
	//temp->tMin = node->tMin;
	update(node);
}

//update tMax by two children
inline void IntervalTree::update(IntervalTNode* &node) {
	int left_max = 0, left_min = 0x7fffffff;
	if (node->left) {
		left_max = node->left->tMax;
		//left_min = node->left->tMin;
	}
	int right_max = 0, right_min = 0x7fffffff;
	if (node->right) {
		right_max = node->right->tMax;
		//right_min = node->right->tMin;
	}
	node->tMax = Util::getMax(left_max, right_max, node->key.endT);
	//node->tMin = Util::getMin(left_min, right_min, node->key.startT);
}

//maintain the property of red-black
void IntervalTree::insertFixUp(IntervalTNode* &mynode) {
	IntervalTNode* node = mynode;
	while (node->parent != NULL && node->parent->color == true) {
		if (node->parent == node->parent->parent->left) {//left subtree
			/*if node->parent exists, node->parent->parent must exist,
			because node->parent->color=='R' and
			node->parent can't be the root
			*/
			IntervalTNode* uncle = node->parent->parent->right;
			if (uncle&&uncle->color == true) {//uncle can be NULL
				uncle->color = false;
				node->parent->color = false;
				node->parent->parent->color = true;
				node = node->parent->parent;
			}
			else {
				if (node == node->parent->right) {//right subtree
					node = node->parent;
					lRotate(node);
				}
				node->parent->color = false;
				node->parent->parent->color = true;
				rRotate(node->parent->parent);
			}
		}
		else {//right subtree
			IntervalTNode* uncle = node->parent->parent->left;
			if (uncle&&uncle->color == true) {//uncle can be NULL
				uncle->color = false;
				node->parent->color = false;
				node->parent->parent->color = true;
				node = node->parent->parent;
			}
			else {
				if (node == node->parent->left) {//right subtree
					node = node->parent;
					rRotate(node);
				}
				node->parent->color = false;
				node->parent->parent->color = true;
				lRotate(node->parent->parent);
			}
		}
	}
	if (this->root->parent)//change the root ptr
		this->root = this->root->parent;
	this->root->color = false;//set the color of root
}

void IntervalTree::release(IntervalTNode* &node) {
	if (node) {
		release(node->right);
		release(node->left);
		delete node;
		node = NULL;
	}
}
#pragma endregion

//encapsulation of insertion
void IntervalTree::insert(Intv& val) {
	if (!this->root) {
		this->root = DBG_NEW IntervalTNode(val);
		insertFixUp(this->root);
		return;
	}
	IntervalTNode *now = this->root;
	IntervalTNode *node;
	while (now != NULL) {
		now->tMax=max(now->tMax, val.endT);
		//now->tMin = min(now->tMin, val.startT);//update from root to leaf node
		if (val > now->key) {//right subtree
			if (now->right) {
				now = now->right;
			}
			else {//null
				now->right = DBG_NEW IntervalTNode(val, now);
				node = now->right;
				break;
			}
		}
		else {//left subtree
			if (now->left) {
				now = now->left;
			}
			else {//null
				now->left = DBG_NEW IntervalTNode(val, now);
				node = now->left;
				break;
			}
		}
	}
	insertFixUp(node);
}

////search all intervals overlap val
//vector<Interval> IntervalTree::search(const Interval& val) {
//	vector<Interval> vec;
//	IntervalTNode *now = this->root;
//	if (now == NULL)return vec;
//	queue<IntervalTNode*> q;
//	q.push(now);
//	while (!q.empty()) {
//		now = q.front();
//		q.pop();
//		if (val.startT <= now->key.endT&&now->key.startT <= val.endT) {
//			vec.push_back(now->key);
//		}
//		if (now->left&&val.startT < now->left->tMax)//left subtree
//			q.push(now->left);
//		if (now->right&&val.endT>now->right->tMin)//right subtree
//			q.push(now->right);
//	}
//	/*if (vec.size()==0)
//		cout << val << " not found" << endl;*/
//	return vec;
//}
//
////search all intervals overlap val with the fixed edgeType
//vector<Interval> IntervalTree::search(const Interval& val,Weight edgeType) {
//	vector<Interval> vec;
//	IntervalTNode *now = this->root;
//	if (now == NULL)return vec;
//	queue<IntervalTNode*> q;
//	q.push(now);
//	while (!q.empty()) {
//		now = q.front();
//		q.pop();
//		if (val.startT <= now->key.endT&&now->key.startT <= val.endT
//			&&now->info == edgeType) {
//			vec.push_back(now->key);
//		}
//		if (now->left&&val.startT < now->left->tMax)//left subtree
//			q.push(now->left);
//		if (now->right&&val.endT>now->right->tMin)//right subtree
//			q.push(now->right);
//	}
//	/*if (vec.size()==0)
//	cout << val << " not found" << endl;*/
//	return vec;
//}

/*search if one node contain the time
	and return a interval if true*/
bool IntervalTree::search(Intv& intv, int time) {
	IntervalTNode *now = this->root;
	if (!now) return false;
	queue<IntervalTNode*> q;
	q.push(now);
	Intv* intvPtr;
	while (!q.empty()) {
		now = q.front();
		q.pop();
		intvPtr = &now->key;
		if (time <= intvPtr->endT&&intvPtr->startT <= time) {
			intv.startT = intvPtr->startT;
			intv.endT = intvPtr->endT;
			intv.value = intvPtr->value;
			return true;
		}
		if (now->left&&time <= now->left->tMax)//left subtree
			q.push(now->left);
		if (now->right&&time >= intvPtr->startT)//right subtree
			q.push(now->right);
	}
	return false;
}

/*search if one node contain the time with the fixed label
	and return a interval if true*/
bool IntervalTree::search(Label edgeType, Intv& intv, int time) {
	IntervalTNode *now = this->root;
	if (!now) return false;
	queue<IntervalTNode*> q;
	q.push(now);
	Intv* intvPtr;
	while (!q.empty()) {
		now = q.front();
		intvPtr = &now->key;
		if (time <= intvPtr->endT&&intvPtr->startT <= time&&edgeType== intvPtr->value) {
			intv.startT = intvPtr->startT;
			intv.endT = intvPtr->endT;
			intv.value = intvPtr->value;
			return true;
		}
		q.pop();
		if (now->left&&time <= now->left->tMax)//left subtree
			q.push(now->left);
		if (now->right&&time >= intvPtr->startT)//right subtree
			q.push(now->right);
	}
	return false;
}


#pragma region used in FTM
/*search if exists a interval of one node contain [startT,endT]
	and return the label,interval's start time and end time */
bool IntervalTree::newContain(const int startT, const int endT,
	Label& edgeType, int& intvStartT, int& intvEndT) {
	IntervalTNode *now = this->root;
	if (!now)return false;
	queue<IntervalTNode*> q;
	q.push(now);
	Intv* intvPtr;
	int tempStartT, tempEndT;
	while (!q.empty()) {
		now = q.front();
		intvPtr = &now->key;
		tempStartT = intvPtr->startT;
		tempEndT = intvPtr->endT;
		if (endT <= tempEndT && tempStartT <= startT) {
			edgeType = intvPtr->value;
			intvStartT = tempStartT;
			intvEndT = tempEndT;
			return true;
		}
		q.pop();
		if (now->left&&startT <= now->left->tMax)//left subtree
			q.push(now->left);
		if (now->right&&endT >= intvPtr->startT)//right subtree
			q.push(now->right);
	}
	return false;
}
#pragma endregion

void IntervalTree::print() {
	if (!this->root) { cout << "empty tree" << endl; return; }
	queue<IntervalTNode* > q;
	q.push(this->root);
	while (!q.empty()) {
		IntervalTNode* now = q.front();
		q.pop();
		cout << now << endl;
		if (now->left)q.push(now->left);
		if (now->right)q.push(now->right);
	}
}

//copy the information in copynode to node
void IntervalTree::copy(IntervalTNode*& parent,
	IntervalTNode*& node, IntervalTNode*& copynode) {
	node->color = copynode->color;
	node->parent = parent;
	node->tMax = copynode->tMax;
	//node->tMin = copynode->tMin;
	if (!copynode->left) {
		node->left = NULL;
	}
	else {
		node->left = DBG_NEW IntervalTNode(copynode->left->key);
		copy(node, node->left, copynode->left);
	}
	if (!copynode->right) {
		node->right = NULL;
	}
	else {
		node->right = DBG_NEW IntervalTNode(copynode->right->key);
		copy(node, node->right, copynode->right);
	}
}

//get all intervals of a tree
//void IntervalTree::getAllIntervals(vector<Intv>& intvList, int k) {
//	IntervalTNode *now = root;
//	if (!now)return;
//	queue<IntervalTNode*> q;
//	q.push(now);
//	Intv* intvPtr;
//	while (!q.empty()) {
//		now = q.front();
//		intvPtr = &now->key;
//		if (intvPtr->endT- intvPtr->startT+1 >= k) {
//			intvList.emplace_back(now->key);
//		}
//		q.pop();
//		if (now->left) {
//			q.push(now->left);
//		}
//		if (now->right) {
//			q.push(now->right);
//		}
//	}
//}

//get all intervals with the fixed edgeType of a tree
//void IntervalTree::getAllIntervals(vector<Intv>& intvList,int k, 
//		unordered_map<int, bool>*& fixedOneLabel) {
//	IntervalTNode *now = root;
//	if (!now)return;
//	queue<IntervalTNode*> q;
//	q.push(now);
//	Intv* intvPtr;
//	unordered_map<int, bool>::iterator fixedOneLabelEnd = fixedOneLabel->end();
//
//	while (!q.empty()) {
//		now = q.front();
//		intvPtr = &now->key;
//		if (fixedOneLabel->find(intvPtr->value) != fixedOneLabelEnd 
//			&&intvPtr->endT - intvPtr->startT + 1 >= k) {
//			intvList.emplace_back(now->key);
//		}
//		q.pop();
//		if (now->left) {
//			q.push(now->left);
//		}
//		if (now->right) {
//			q.push(now->right);
//		}
//	}
//}

//update interval's endT of nodes
void IntervalTree::updateNode(Intv& intv, int newEndT) {
	IntervalTNode *now = this->root;
	while (now) {
		now->tMax = max(now->tMax, newEndT);//update from root to leaf node
		if (intv.startT > now->key.startT) {//right subtree
			if (now->right) {
				now = now->right;
			}
			else {//impossible condition
				cout << "interval doesn't exist" << endl;
				exit(-1);
			}
		}
		else if (intv.startT < now->key.startT) {//left subtree
			if (now->left) {
				now = now->left;
			}
			else {//impossible condition
				cout << "interval doesn't exist" << endl;
				exit(-1);
			}
		}
		else {
			now->key.endT = newEndT;
			break;
		}
	}
}

//test
//int main() {
//	/*
//	                     2-4B
//		     1-4R                     3-4R
//	   1-2B         2-3B        2-5B        4-5B
//	      1-3R   1-5R                     3-5R
//	*/
//	IntervalTree* a = new IntervalTree();
//	a->insert(Interval(1, 2));
//	a->insert(Interval(2, 3));
//	a->insert(Interval(1, 4));
//	a->insert(Interval(4, 5));
//	a->insert(Interval(2, 4));
//	a->insert(Interval(2, 5));
//	a->insert(Interval(3, 4));
//	a->insert(Interval(1, 5));
//	a->insert(Interval(1, 3));
//	a->insert(Interval(3, 5));
//	a->print();
//	cout << "==================================\n";
//	Interval intv(2, 3);
//	vector<Interval> v=a->search(intv);
//	vector<Interval>::iterator iter=v.begin();
//	cout << "search "<<intv<<" result:"<<endl;
//	for (; iter != v.end(); iter++) {
//		cout << *iter << endl;
//	}
//	system("pause");
//}
