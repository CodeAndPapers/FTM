#pragma once
#include "stdafx.h"
#include "Interval.h"
#include "Util.h"
using Intv = Interval<int, Label>;
/*New Tree whose balance property is maintained by red-black tree
characteristics: different nodes's intervals have not intersections
*/
class NewTNode {
public:

	NewTNode(const NewTNode& node)
		:key(node.key), left(node.left), right(node.right), parent(node.parent),
		color(node.color) {}

	NewTNode(const Intv& val)
		:key(val), left(NULL), right(NULL), parent(NULL), color(true) {}

	NewTNode(const Intv& val, NewTNode* &parent)
		:key(val), left(NULL), right(NULL), parent(parent), color(true) {}

	friend ostream& operator<<(ostream& out, const NewTNode*node) {
		out << "key:" << node->key
			<< "\tcolor:" << node->color;
		return out;
	}

	~NewTNode() = default;

	NewTNode*left, *right, *parent;//left\right child��parent node  24byte
	/*range : max right endpoint of interval in the subtree and
	min left endpoint of interval in the subtree*/
	//int maxV, minV; // 8byte
	Intv key;//interval // 12byte
	bool color;//true(RED) or false(BLACK) 1byte
};

class ICTree {
public:
	ICTree() :root(NULL) {}

	ICTree(const ICTree& tree) {
		root = DBG_NEW NewTNode(tree.root->key);
		root->color = tree.root->color;
		if (tree.root->left) {
			copy(root, root->left, tree.root->left);
		}
		if (tree.root->right) {
			copy(root, root->right, tree.root->right);
		}
	}

	/*search if one node contain the time
	and return a interval if true*/
	bool search(Intv& intv, int time);

	/*search if one node contain the time with the fixed label
	and return a interval if true */
	bool search(Label edgeType, Intv& intv, int time);

	//encapsulation of insertion
	void insert(const Intv& val);

	#pragma region used in general case
	/*search if exists a interval of one node contain [startT,endT]
	and return the label,interval's start time and end time */
	bool newContain(const int startT, const int endT, 
		Label& edgeType, int& intvStartT, int& intvEndT);
	#pragma endregion

	void print();

	~ICTree() {
		release(root);
	}

	//copy the information in copynode to node
	void copy(NewTNode*& parent,
		NewTNode*& node, NewTNode*& copynode);

	//update interval's endT of nodes
	void updateNode(Intv& intv, int newEndT);

	#pragma region maintain interval tree
	//update minV/maxV after insertion
	void update(int minT, int maxT);
	#pragma endregion 
private:
	NewTNode* root;

	#pragma region maintain interval tree
	//set root node
	inline void setRoot(Intv& val) {
		this->root = DBG_NEW NewTNode(val);
	}

	//rotate right
	void rRotate(NewTNode* &node);

	//rotate left
	void lRotate(NewTNode* &node);

	//maintain the property of red-black
	void insertFixUp(NewTNode* &node);

	//release memory
	void release(NewTNode* &node);
	#pragma endregion
};