#pragma once
#include "stdafx.h"

/*one node of a link list*/
template<typename T>
class LinkedNode {
public:
	LinkedNode(T& vec)
		:item(DBG_NEW T(vec)),
		 next(NULL){}

	LinkedNode(T*& vec)
		:item(DBG_NEW T(*vec))
		/*item(vec)*/, next(NULL) {}

	~LinkedNode() {
		//item->clear();
		delete item;
		next = NULL;
	}

	LinkedNode<T>* next;//next node
	T* item;
};

/*one header of a link list*/
template<typename Y>
class LinkedHead {
public:
	LinkedHead():length(0),next(NULL),tail(NULL) {}

	void addNode(LinkedNode<Y>& node) {
		if (!length)tail = &node;
		node.next = this->next;
		this->next = &node;
		length ++;
	}

	void addNode(LinkedNode<Y>*& node) {
		if (!length)tail = node;
		node->next = this->next;
		this->next = node;
		length++;
	}

	//add the link list with header head(remove the head after adding)
	void addChain(LinkedHead<Y>& head) {
		if (!head.length)return;
		if (!length)tail = head.tail;
		head.tail->next = this->next;
		this->next = head.next;
		length += head.length;
		head.next = NULL;//for delete
	}

	//add the link list with header head(remove the head after adding)
	void addChain(LinkedHead<Y>*& head) {
		if (!head->length)return;
		if (!length)tail = head->tail;
		head->tail->next = this->next;
		this->next = head->next;
		length += head->length;
		head->next = NULL;//for delete
	}

	//delete node after the current node
	void deleteNextNode(LinkedNode<Y>& node) {
		LinkedNode<Y>* one = node.next;
		if (!one)return;
		node.next = one->next;
		if (!one->next)tail = &node;
		one->next = NULL;
		delete one;
		length -= 1;
	}

	//delete first node
	void deleteFirstNode() {
		LinkedNode<Y>* one = this->next;
		if (!one)return;
		this->next=one->next;
		tail = one->next;
		one->next = NULL;
		delete one;
		length -= 1;
	}

	~LinkedHead() {
		LinkedNode<Y>* one;
		while (next != NULL) {
			one = next;
			next = next->next;
			delete one;
		}
	}

	int length;//length of linked list
	LinkedNode<Y>* next;//next node
	LinkedNode<Y>* tail;//tail node
};



#pragma region testing

/*one node of a list*/
template<typename T>
class LinkedNodeV {
public:
	LinkedNodeV(T& vec)
		:item(vec),
		next(NULL) {}

	~LinkedNodeV() {
		next = NULL;
	}

	LinkedNodeV<T>* next;//next node
	T item;
};

/*one header of a link list*/
template<typename Y>
class LinkedHeadV {
public:
	LinkedHeadV() :length(0), next(NULL), tail(NULL) {}

	void addNode(LinkedNodeV<Y>& node) {
		if (!length)tail = &node;
		node.next = this->next;
		this->next = &node;
		length++;
	}

	void addNode(LinkedNodeV<Y>*& node) {
		if (!length)tail = node;
		node->next = this->next;
		this->next = node;
		length++;
	}

	//add the link list with header head(remove the head after adding)
	void addChain(LinkedHeadV<Y>& head) {
		if (!head.length)return;
		if (!length)tail = head.tail;
		head.tail->next = this->next;
		this->next = head.next;
		length += head.length;
		head.next = NULL;//for delete
	}

	//add the link list with header head(remove the head after adding)
	void addChain(LinkedHeadV<Y>*& head) {
		if (!head->length)return;
		if (!length)tail = head->tail;
		head->tail->next = this->next;
		this->next = head->next;
		length += head->length;
		head->next = NULL;//for delete
	}

	//delete node after the current node
	void deleteNextNode(LinkedNodeV<Y>& node) {
		LinkedNodeV<Y>* one = node.next;
		if (!one)return;
		node.next = one->next;
		if (!one->next)tail = &node;
		one->next = NULL;
		delete one;
		length -= 1;
	}

	//delete first node
	void deleteFirstNode() {
		LinkedNodeV<Y>* one = this->next;
		if (!one)return;
		this->next = one->next;
		tail = one->next;
		one->next = NULL;
		delete one;
		length -= 1;
	}

	~LinkedHeadV() {
		LinkedNodeV<Y>* one;
		while (next != NULL) {
			one = next;
			next = next->next;
			delete one;
		}
	}

	int length;//length of linked list
	LinkedNodeV<Y>* next;//next node
	LinkedNodeV<Y>* tail;//tail node
};
#pragma endregion