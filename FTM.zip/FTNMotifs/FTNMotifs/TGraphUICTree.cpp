#include"TGraphUICTree.h"
#include"stdafx.h"

TGraphUICTree::TGraphUICTree(const TGraphUICTree& ances) :TGraph(ances) {
	*tree = *ances.tree;
}

#pragma region construct and update the temporal graph
/* construct the temporal graph
1) graph file: each line of the file describe an edge in a timestamp.
each line has four number: u,v,t,w (separated by ',' with no other space)
for weight w of edge (u,v) in time t. Ids of node u and v are not guaranteed to be
continuous, while the timestamps t are continuous, i.e. all edges in time 0 come
first, and followed by edges in time 1, 2...
*/
void TGraphUICTree::constructGraph(const char* src) {
	vec(int) u_arr, v_arr, t_arr;
	vec(Label) w_arr;
	set<Edge> origEdge;
	loadInformation(src, origEdge, u_arr, v_arr, t_arr, w_arr);

	clock_t startTime, endTime;
	startTime = clock();
	loadTGraphWeights(u_arr, v_arr, t_arr, w_arr/*, name2id*/);
	endTime = clock();
	cout << "load: " << endTime - startTime << "ms" << endl;
}

/*construct the temporal graph, but fixed the startT and endT*/
void TGraphUICTree::constructGraph(const char* src,
	int startT, int endT) {
	vec(int) u_arr, v_arr, t_arr;
	vec(Label) w_arr;
	set<Edge> origEdge;
	loadInformation(src, origEdge, u_arr, v_arr, t_arr, w_arr,
		startT, endT);

	clock_t startTime, endTime;
	startTime = clock();
	loadTGraphWeights(u_arr, v_arr, t_arr, w_arr/*, name2id*/);
	endTime = clock();
	cout << "load: " << endTime - startTime << "ms" << endl;
}

//increase snapshots of the temporal graph
void TGraphUICTree::changeGraph(const char* src, int oldEndT, int limitNewEndT) {
	vec(int) u_arr, v_arr, t_arr;
	vec(Label) w_arr;//allocate the memory
	u_arr.reserve(ALLOC_MEM);
	v_arr.reserve(ALLOC_MEM);
	t_arr.reserve(ALLOC_MEM);
	w_arr.reserve(ALLOC_MEM);
	int u, v, t;
	Label w;

#pragma region load file
	FILE* file;
	file = fopen(src, "r+");
	if (!file) exit(-1);
	char line[LINE_LENGTH];
	CLEARALL(line, 0, LINE_LENGTH, char);
	int sep1, sep2, sep3;//separator pos
	int newEndT = oldEndT, oldTimestamp;
	if (limitNewEndT == -1) limitNewEndT = 0x7fffffff;
	try {
		while (fgets(line, LINE_LENGTH, file)) {
			if (strlen(line) == 0) continue;
			sep1 = (int)(find(line, line + LINE_LENGTH, SEP_CHAR) - line);
			sep2 = (int)(find(line + sep1 + 1, line + LINE_LENGTH, SEP_CHAR) - line);
			sep3 = (int)(find(line + sep2 + 1, line + LINE_LENGTH, SEP_CHAR) - line);
			u = STR2INT(line);
			v = STR2INT(line + sep1 + 1);
			t = STR2INT(line + sep2 + 1);
			w = STR2INT(line + sep3 + 1);

			if (t > oldEndT&&t <= limitNewEndT) {
				if (t > newEndT)newEndT = t;//new endT
				u_arr.emplace_back(u);
				v_arr.emplace_back(v);
				t_arr.emplace_back(t);
				w_arr.emplace_back(w);
			}
		}
		fclose(file);
		this->endT = newEndT;//update endT of graph
		oldTimestamp = this->nTimestamp;
		this->nTimestamp = newEndT - this->startT + 1;
	}
	catch (exception& e) {
		Util::printError(e);
		cout << "load error" << endl;
	}
#pragma endregion
	clock_t startTime, endTime;
	startTime = clock();

	int newTimestamp = newEndT - oldEndT;
	int newStartT = oldEndT + 1;
	Label** eW = DBG_NEW Label*[newTimestamp];//edge's new weight
	for (int i = 0; i < newTimestamp; i++) {
		eW[i] = DBG_NEW Label[nEdge];
		for (int j = 0; j < nEdge; j++) {
			eW[i][j] = 0x7fffffff;
		}
	}
	delete[] intvForEdges;
	intvForEdges = DBG_NEW Intv[nEdge];

#pragma region prepare for updating
	int edgeInd;
	size_t length = u_arr.size();
	for (size_t i = 0; i < length; i++) {
		u = u_arr[i];
		v = v_arr[i];
		t = t_arr[i];
		w = w_arr[i];

		Edge e(u, v);
		edgeInd = edge2ind->find(e)->second;
		if (eW[t - newStartT][edgeInd] == 0x7fffffff)
			eW[t - newStartT][edgeInd] = w;
	}
#pragma endregion

#pragma region update index
	Label nowW, breW;
	int intv_s;//current Intv's start time
	Intv updateIntv;
	Intv intv;
	int intvLen, pos;
	for (int id = 0; id < nEdge; id++) {//O(E)
		tree[id]->search(updateIntv, oldEndT);
		intv_s = updateIntv.startT;
		breW = updateIntv.value;
		for (int i = oldEndT + 1; i <= newEndT; i++) {//O(deltaT)
			pos = i - oldEndT - 1;
			nowW = eW[pos][id];
			if (nowW != breW) {//next Intv
				if (i != oldEndT + 1) {
					intvLen = i - intv_s;
					intv.setValue(intv_s, i - 1, breW);
					maxIntervalLength = max(maxIntervalLength, intvLen);
					if (intv_s <= oldEndT) {//change interval
						tree[id]->updateNode(intv, i - 1);//log(n)
					}
					else {//new interval
						tree[id]->insert(intv);
					}
				}
				intv_s = i;//update
				breW = nowW;
			}
		}
		intvLen = newEndT - intv_s + 1;
		maxIntervalLength = max(maxIntervalLength, intvLen);
		if (intv_s <= oldEndT) {//change interval
			intv.setValue(intv_s, newEndT, breW);
			tree[id]->updateNode(intv, newEndT);//log(n)
		}
		else {//new interval
			intv.setValue(intv_s, newEndT, breW);
			tree[id]->insert(intv);
		}
		tree[id]->update(startT, endT);
	}
	for (int i = 0; i < newTimestamp; i++) {
		delete[]eW[i];
	}
	delete[]eW;
	endTime = clock();
	cout << "update: " << endTime - startTime << "ms" << endl;
#pragma endregion
}
#pragma endregion

#pragma region save temporal graph to index
/*
four vectors save four number u,v,t,w respectively
u_arr,v_arr,t_arr,w_arr are created in funtion constructGraph
*/
void TGraphUICTree::loadTGraphWeights(vec(int)& u_arr, vec(int)& v_arr,
	vec(int)& t_arr, vec(Label)& w_arr) {
	Label** eW = DBG_NEW Label*[nTimestamp];
	for (int i = 0; i < nTimestamp; i++) {
		eW[i] = DBG_NEW Label[nEdge];
		for (int j = 0; j < nEdge; j++) {
			eW[i][j] = 0x7fffffff;
		}
	}
	intvForEdges = DBG_NEW Intv[nEdge];
	tree = DBG_NEW ICTree*[nEdge];//use Intv tree
	int u, v, t, edgeInd;
	Label w;
	size_t length = u_arr.size();
	for (size_t i = 0; i < length; i++) {
		u = u_arr[i];
		v = v_arr[i];
		t = t_arr[i];
		w = w_arr[i];

		Edge e1(u, v);
		edgeInd = edge2ind->find(e1)->second;
		if (eW[t - startT][edgeInd] == 0x7fffffff)
			eW[t - startT][edgeInd] = w;
	}

	Label nowW, breW;
	int intervalLen;
	int intv_s;//current Intv's start time
	//oriSearchT = 0;
	int intvNum = 0;// number of intervals
	long long intvSum = 0;// sum of intervals number
	int maxIntvNum = 0;// maximum number of intervals
	for (int id = 0; id < nEdge; id++) {//O(E)
		breW = eW[0][id];
		intv_s = startT;
		tree[id] = DBG_NEW ICTree();//create the tree 
		for (int i = startT + 1; i <= endT; i++) {//O(T)
			nowW = eW[i - startT][id];
			if (nowW != breW) {//next Intv
				tree[id]->insert(Intv(intv_s, i - 1, breW));
				intvNum++;
				intervalLen = i - intv_s;
				maxIntervalLength = max(maxIntervalLength, intervalLen);
				intv_s = i;//update
				breW = nowW;
			}
		}
		tree[id]->insert(Intv(intv_s, endT, breW));
		intvNum++;
		intvSum += intvNum;
		maxIntvNum = max(maxIntvNum, intvNum);
		intvNum = 0;
		intervalLen = endT - intv_s + 1;
		maxIntervalLength = max(maxIntervalLength, intervalLen);
		tree[id]->update(startT, endT);
	}
	cout << INTV_NUM << maxIntvNum << endl;
	cout << MEAN_INTV_NUM << intvSum * 1.0 / nEdge << endl;
	for (int i = 0; i < nTimestamp; i++) {
		delete[]eW[i];
	}
	delete[]eW;

	cout << "Balance trees: " << (37 * intvSum + 8 * (nEdge + 1)) << "Byte" << endl;
}
#pragma endregion


/*compRES for FTM*/
void TGraphUICTree::getCandidate(int intvB, int intvE,
	SAVEINFO_Vec*& selectedEdge, int& selectedNum/*,
	unordered_map<int, bool>& fixLabel, bool isEdgeTypeFixed*/) {
	//int timePos = intvB - startT;
	Label edgeType;
	//unordered_map<int, bool>::iterator fixLabelEnd = fixLabel.end();
	int intvLen = intvE - intvB + 1;
	int rtnStartT, rtnEndT;
	for (int i = 0; i < nEdge; i++) {//O(|E|)
		if (intvForEdges[i].endT >= intvE && intvForEdges[i].startT <= intvB) {//case 4
			edgeType = intvForEdges[i].value;
			/*if (!isEdgeTypeFixed ||
				fixLabel.find(edgeType) != fixLabelEnd) {*/
				selectedNum++;
				selectedEdge[intvForEdges[i].endT - intvE].
					emplace_back(i, intvForEdges[i].startT, edgeType);
			/*}*/
		}
		else if (intvForEdges[i].endT >= intvB && intvForEdges[i].startT <= intvE) {//case 3
			continue;
		}
		else {//case 1 and 2
			bool flag = tree[i]->newContain(intvB, intvE, edgeType, rtnStartT, rtnEndT);
			intvForEdges[i].endT = rtnEndT;
			intvForEdges[i].startT = rtnStartT;
			intvForEdges[i].value = edgeType;
			if (flag && rtnEndT >= intvE/*&& (!isEdgeTypeFixed ||
					fixLabel.find(edgeType) != fixLabelEnd)*/) {
				selectedNum++;
				selectedEdge[rtnEndT - intvE].emplace_back(i, rtnStartT, edgeType);
			}
		}
	}
}


/*get the label of edge with edgeId at the time*/
Label TGraphUICTree::getWeight(int time, int edgeId) {
	Intv intv;
	tree[edgeId]->search(intv, time);
	return intv.value;
}

/*compRES for DFTM (row number<=T-k+1)*/
void TGraphUICTree::getCandidateForDynamicGCM2(int intvB, int intvE,
	SAVEINFO_Vec*& selectedEdge, int& selectedNum,
	int oriEndT, /*unordered_map<Label, bool>& fixLabel,
	bool isEdgeTypeFixed,*/ int k, vec(TNMotif*)& result) {
	//int timePos = intvB - startT;
	Label edgeType;
	//unordered_map<int, bool>::iterator fixLabelEnd = fixLabel.end();
	int intvLen = intvE - intvB + 1;
	int endTime = intvB + k - 1;
	int rtnStartT, rtnEndT;
	int compareT = oriEndT;
	veciter(TNMotif*) iterEnd = result.end();
	TNMotif* tempMotif;
	vec(TEdge)* motifEdge;
	veciter(TEdge) edgeIterEnd;
	int id;
	for (auto iter = result.begin(); iter != iterEnd; ++iter) {
		tempMotif = *iter;
		motifEdge = tempMotif->getMotifEdge();
		edgeIterEnd = motifEdge->end();
		for (auto edgeIter = motifEdge->begin();
			edgeIter != edgeIterEnd; ++edgeIter) {
			id = edgeIter->id;
			if (intvForEdges[id].endT >= intvE && intvForEdges[id].startT <= intvB) {//case 4
				edgeType = intvForEdges[id].value;
				if (/*(!isEdgeTypeFixed ||
					fixLabel.find(edgeType) != fixLabelEnd)
					&&*/ intvForEdges[id].endT >= compareT) {
					selectedNum++;
					selectedEdge[intvForEdges[id].endT - compareT].
						emplace_back(id, intvForEdges[id].startT, edgeType);
				}
			}
			else if (intvForEdges[id].endT >= intvB && intvForEdges[id].startT <= intvE) {//case 3
				continue;
			}
			else {//case 1 and 2
				bool flag = tree[id]->newContain(intvB, endTime, edgeType, rtnStartT, rtnEndT);
				intvForEdges[id].endT = rtnEndT;
				intvForEdges[id].startT = rtnStartT;
				intvForEdges[id].value = edgeType;
				if (flag/* && (!isEdgeTypeFixed ||
						fixLabel.find(edgeType) != fixLabelEnd)*/) {
					if (rtnEndT >= compareT) {
						selectedNum++;
						selectedEdge[rtnEndT - compareT].emplace_back(id, rtnStartT, edgeType);
					}
				}
			}
		}
	}
}
