#pragma once
#include "stdafx.h"
#include"Interval.h"
#include"Util.h"
using Intv = Interval<int, Label>;
//Interval Tree whose balance property is maintained by red-black tree 
class IntervalTNode{
public:
	
	IntervalTNode(const IntervalTNode& node)
		:key(node.key),tMax(node.tMax),/*tMin(node.tMin),*/
		left(node.left),right(node.right),parent(node.parent),
	    color(node.color){}

	IntervalTNode(Intv& val)
		:key(val), tMax(val.endT), /*tMin(val.startT) ,*/
		left(NULL),right(NULL), parent(NULL), color(true){}

	IntervalTNode(Intv& val, IntervalTNode* &parent) 
		:key(val), tMax(val.endT), /*tMin(val.startT),*/
		left(NULL), right(NULL), parent(parent), color(true) {}

	friend ostream& operator<<(ostream& out, const IntervalTNode*node) {
		out << "key:" << node->key
			<< "\tcolor:" << node->color
			<<"\ttMax:"<<node->tMax;
			//<<"\ttMin:"<<node->tMin
		return out;
	}

	~IntervalTNode() = default;

	IntervalTNode*left, *right, *parent;//left\right child��parent node  24byte
	Intv key;//interval  12byte
	bool color;//true(RED) or false(BLACK)  1byte
	int tMax;//max right endpoint of interval in the subtree  4byte
};

class IntervalTree {
public:
	IntervalTree():root(NULL){}
	
	IntervalTree(const IntervalTree& tree) {
		root = DBG_NEW IntervalTNode(tree.root->key);
		root->color = tree.root->color;
		root->tMax = tree.root->tMax;
		//root->tMin = tree.root->tMin;
		if (tree.root->left) {
			copy(root, root->left, tree.root->left);
		}
		if (tree.root->right) {
			copy(root, root->right, tree.root->right);
		}
	}

	//encapsulation of insertion
	void insert(Intv& val);

	/*search if one node contain the time 
	and return a interval if true*/
	bool search(Intv& intv, int time);

	/*search if one node contain the time with the fixed label
	and return a interval if true */
	bool search(Label edgeType, Intv& intv, int time);

	#pragma region used in FTM
	/*search if exists a interval of one node contain [startT,endT]
	and return the label,interval's start time and end time */
	bool newContain(const int startT, const int endT,
		Label& edgeType, int& intvStartT, int& intvEndT);
	#pragma endregion

	void print();

	~IntervalTree() {
		release(root);
	}

	//copy the information in copynode to node
	void copy(IntervalTNode*& parent,
		IntervalTNode*& node, IntervalTNode*& copynode);

	//update interval's endT of nodes
	void IntervalTree::updateNode(Intv& intv, int newEndT);

private:
	IntervalTNode* root;

	#pragma region maintain interval tree
	//set root node
	inline void setRoot(Intv& val) {
		this->root = DBG_NEW IntervalTNode(val);
	}

	//rotate right
	void rRotate(IntervalTNode* &node);

	//rotate left
	void lRotate(IntervalTNode* &node);
	
	//maintain the property of red-black
	void insertFixUp(IntervalTNode* &node);
	
	//update tMax by two children
	inline void IntervalTree::update(IntervalTNode* &node);

	//release memory
	void release(IntervalTNode* &node);
	#pragma endregion
};