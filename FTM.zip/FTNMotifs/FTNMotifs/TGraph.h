#pragma once
#include "stdafx.h"
#include "TGraph.h"
#include "TNMotif.h"
#include "Util.h"
#include "Edge.h"
#include "UnionFindSet.h"
#include "IntervalTree.h"
#include "LinkedList.h"

#define ALLOC_MEM 20000000
/*map the interval [Ts,Te] to the one dimension position of result*/
#define resultPos(Ts,Te,startT,endT,k) ((Ts - startT)*((endT<<1) - startT - Ts - (k<<1) + 5) >>1) + Te - (Ts + k - 1)

/* Temporal Graph: the nodes and edges are fixed
   and the weights vary with time*/
class TGraph {
public:
	using Intv = Interval<int, Label>;

	TGraph() { ufset = NULL; }
	// copy-constructed
	TGraph(const TGraph& ances);

	inline int getNTimestamp() const { return nTimestamp; }

	inline size_t getNNode() const { return nNode; }

	inline size_t getNEdge() const { return nEdge; }

	inline int getStartT() const { return startT; }

	inline int getEndT() const { return endT; }

	inline void setStartT(int startT) { this->startT=startT; }

	inline void setEndT(int endT) { this->endT=endT; }

	inline void getEdgeList(Edge*& s) { s = edgeList; }

	inline void getEdge2Ind(map<Edge, int> *& e2i) { e2i = edge2ind; }

	//output the information of TGraph conveniently
	friend ostream& operator<<(ostream& output, const TGraph& e) {
		output << "Input temporal graph information:" << endl;
		output << "number of node: " << e.nNode << "\tnumber of edge: " << e.nEdge << endl;
		output << "time length: " << e.nTimestamp <<
			"\tstart time: " << e.startT << "\tend time: " << e.endT << endl;
		return output;
	}
	
	virtual ~TGraph() {
		delete[] edgeList;
		delete edge2ind;
		if(ufset != NULL)
			delete ufset;
	}

	#pragma region construct and update the temporal graph
	/*
	construct the temporal graph
	1) graph file: each line of the file describe an edge in a timestamp.
	each line has four number: u,v,t,w (separated by ',' with no other space)
	for weight w of edge (u,v) in time t. Ids of node u and v are not guaranteed to be
	continuous, while the timestamps t are continuous, i.e. all edges in time 0 come
	first, and followed by edges in time 1, 2...
	*/
	virtual void constructGraph(const char* src)=0;
	
	/*construct the temporal graph, but fixed the startT and endT*/
	virtual void constructGraph(const char* src,int startT,int endT) = 0;

	//increase snapshots of the temporal graph
	virtual void changeGraph(const char* src, int oldEndT, int limitNewEndT) = 0;
	#pragma endregion

	/*print motif*/
	void printMotif(TNMotif* motif);
	/*count vertex number of motif*/
	//void checkVertex(TNMotif* motif);

	#pragma region FTM
		/*FTM*/
		void getAllMotifsM2(int k, vec(TNMotif*)*& result,
			/*i2bHMap& fixLabel, bool isEdgeTypeFixed,*/ long long& motifNumber,
			int choiceStartT, int choiceEndT);

	#pragma region FTM step 1
		/*compRES*/
		virtual void getCandidate(int intvB, int intvE,
			SAVEINFO_Vec*& selectedEdge, int& selectedNum/*,
			unordered_map<Label, bool>& fixLabel,
			bool isEdgeTypeFixed*/) = 0;
	#pragma endregion 

	#pragma region FTM step 2 and 3
			/*get motifs in one interval for general case method2*/
		void getMotifInOneIntvM2(SAVEINFO_VIter& iterStart, SAVEINFO_VIter& iterEnd,
			i2iHMap& tempVertex2Pos, UnionFindSet*& tempUfset, int& vertexNum,
			vec(int)& combineMotifPos, int& realMotifNum,
			i2iHMap& root2Comp, vec(TempMotif*)& tempMotifList,
			vec(int)& saveMotifPos, int motifStartT, int motifEndT,
			vec(TNMotif*)*& result, int pos,
			long long& motifNumber);

		/*insert the edge's two endpoints into the union-find set (maintain connectivity)*/
		void insertIntoDisjointSet(SAVEINFO_VIter& infoBegin,
			SAVEINFO_VIter& infoEnd,
			i2iHMap& edgeMap, UnionFindSet*& ufset, int&vertexNum,
			vec(int)& combineMotifPos);
		/*combine components which are connected (generateMaxTM case 3)*/
		void combineComponents(vec(TempMotif*)& motifList,
			i2iHMap& edgeMap, UnionFindSet*& ufset,
			i2iHMap& rootMap, /*int& motifListSize,*/int& realMotifNum,
			vec(int)& combineMotifPos);
		/*insert edge into generated motif or generate new motif and check left expandable
			generateMaxTM and generateExpTM*/
		void updateNewEdgeInfo(
			SAVEINFO_VIter& infoBegin, SAVEINFO_VIter& infoEnd,
			vec(TempMotif*)& motifList,
			i2iHMap& edgeMap, UnionFindSet*& ufset,
			i2iHMap& rootMap, /*int& motifListSize,*/ int& realMotifNum,
			vec(int)& saveMotifPos, int startTime);
		/*save generated motifs into result*/
		void saveResult(vec(int)&saveMotifPos,
			vec(TempMotif*)& motifList,
			vec(TNMotif*)& result, int motifStartT, int motifEndT,
			long long& motifNumber);
	#pragma endregion 

	#pragma endregion

	/*DFTM (row number<=T-k+1)*/
	void getAllMotifsDynamicGM2(int k, vec(TNMotif*)*& newResult, int oriEndT,
		/*i2bHMap& fixLabel, bool isEdgeTypeFixed,*/ long long& motifNumber);

	/*compRES for DFTM (row <= T-k+1)*/
	virtual void getCandidateForDynamicGCM2(int intvB, int intvE,
		SAVEINFO_Vec*& selectedEdge, int& selectedNum,
		int oriEndT,
		/*unordered_map<Label, bool>& fixLabel,
		bool isEdgeTypeFixed,*/ int k, vec(TNMotif*)& result) = 0;


	//reset vertexToId and union-find set
	/*void resetStructure() {
		vertexToId.clear();
		ufset->initialize();
	}*/
protected:
	#pragma region save temporal graph to index
	/*
	load the graph weight and create the eL structure, interval trees, 
	and new balanced trees
	four vectors save four number u,v,t,w respectively
	u_arr,v_arr,t_arr,w_arr are created in funtion constructGraph
	*/
	virtual void loadTGraphWeights(vec(int)& u_arr, vec(int)& v_arr,
		vec(int)& t_arr, vec(Label)& w_arr) = 0;

	//save all information from temporal graph
	void loadInformation(const char*& src, set<Edge>& origEdge,
		vec(int)& u_arr, vec(int)& v_arr,
		vec(int)& t_arr, vec(Label)& w_arr);

	//save all information from temporal graph with interval [fixedS, fixedE]
	void loadInformation(const char*& src, set<Edge>& origEdge,
		vec(int)& u_arr, vec(int)& v_arr,
		vec(int)& t_arr, vec(Label)& w_arr,
		int fixedS,int fixedE);
	#pragma endregion

	#pragma region auxiliary variable and structure 
		int nTimestamp;	// number of snapshots
		int startT, endT; // beginning timestamp and ending timestamp
		size_t nNode, nEdge; // number of nodes and edges
		Edge* edgeList;// map edges' ids to its object
		int maxIntervalLength;//used for reducing memory of R edge set
		UnionFindSet* ufset;//disjoint set
		unordered_map<int, int> vertexToId;// map from name of nodes to its id convenient for union find set
		map<Edge, int> *edge2ind; // map from an edge to its id, only used for output
	#pragma endregion
};


//
///*only for testing*/
//class TGraphTest :public TGraph {
//public:
//
//	TGraphTest() { cout << "testing" << endl; }
//	
//	//output the information of TGraph conveniently
//	friend ostream& operator<<(ostream& output, const TGraphTest& e) {
//		output << "Input temporal graph information:" << endl;
//		output << "number of node: " << e.nNode << "\tnumber of edge: " << e.nEdge << endl;
//		output << "time length: " << e.nTimestamp <<
//			"\tstart time: " << e.startT << "\tend time: " << e.endT << endl;
//		return output;
//	}
//
//	~TGraphTest() {
//		for (int i = 0; i < nTimestamp; i++) {
//			delete[]eW[i];
//		}
//		delete[]eW;
//		delete[] adjacentList;
//		delete[] id2vertex;
//	}
//
//#pragma region construct and update the temporal graph
//	/*
//	construct the temporal graph
//	1) graph file: each line of the file describe an edge in a timestamp.
//	each line has four number: u,v,t,w (separated by ',' with no other space)
//	for weight w of edge (u,v) in time t. Ids of node u and v are not guaranteed to be
//	continuous, while the timestamps t are continuous, i.e. all edges in time 0 come
//	first, and followed by edges in time 1, 2...
//	*/
//	void constructGraph(const char* src);
//
//	/*construct the temporal graph, but fixed the startT and endT*/
//	void constructGraph(const char* src, int startT, int endT);
//#pragma endregion
//
//protected:
//	void changeGraph(const char* src, int oldEndT, int limitNewEndT) {}
//	void checkKeepFixed(int intvB, int intvE,
//		vec(TEdge)& selectedEdge/*,
//		unordered_map<Label, bool>& fixLabel, bool isEdgeTypeFixed*/) {}
//	bool checkLExpandable(int beginT, int edgeId) { return false; }
//	bool checkFrequency(int edgeId, int time) { return false; }
//	void getCandidate(int intvB, int intvE,
//		SAVEINFO_Vec*& selectedEdge, int& selectedNum/*,
//		unordered_map<Label, bool>& fixLabel,
//		bool isEdgeTypeFixed*/) {}
//	void getCandidateForDynamicGCM2(int intvB, int intvE,
//		SAVEINFO_Vec*& selectedEdge, int& selectedNum,
//		int oriEndT,
//		/*unordered_map<Label, bool>& fixLabel,
//		bool isEdgeTypeFixed,*/ int k, vec(TNMotif*)& result) {}
//private:
//#pragma region save temporal graph to index
//	/*
//	load the graph weight and create the eL structure, interval trees,
//	and new balanced trees
//	four vectors save four number u,v,t,w respectively
//	u_arr,v_arr,t_arr,w_arr are created in funtion constructGraph
//	*/
//	void loadTGraphWeights(vec(int)& u_arr, vec(int)& v_arr,
//		vec(int)& t_arr, vec(Label)& w_arr/*,
//		unordered_map<int, int>* &name2id*/);
//#pragma endregion 
//
//#pragma region structure 
//#pragma region original graph
//	LinkedHeadV<int>* adjacentList;
//	int* id2vertex;// map nodes' ids to its name
//	Label** eW; // temporal graph label  eW[t][edgeId] O(TE)
//#pragma endregion
//#pragma endregion  
//};