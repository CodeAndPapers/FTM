#include "ICTree.h"
#include "stdafx.h"

#pragma region maintain interval tree
//rotate right
void ICTree::rRotate(NewTNode* &mynode) {
	NewTNode* node = mynode;
	if (!node)return;
	NewTNode* temp = node->left;
	if (!temp)return;
	node->left = temp->right;//right subtree of temp put in root->left
	if (temp->right)temp->right->parent = node;//the right node!=NULL
	temp->right = node;//root put in right subtree of temp
	if (node->parent&&node->parent->left == node) {
		node->parent->left = temp;
	}
	else if (node->parent) {
		node->parent->right = temp;
	}
	temp->parent = node->parent;
	node->parent = temp;
}

//rotate left
void ICTree::lRotate(NewTNode* &mynode) {
	NewTNode* node = mynode;
	if (!node)return;
	NewTNode* temp = node->right;
	if (!temp)return;
	node->right = temp->left;//left subtree of temp put in root->right
	if (temp->left)temp->left->parent = node;//the right node!=NULL
	temp->left = node;//root put in left subtree of temp
	if (node->parent&&node->parent->left == node) {
		node->parent->left = temp;
	}
	else if (node->parent) {
		node->parent->right = temp;
	}
	temp->parent = node->parent;
	node->parent = temp;
}

//update minV/maxV after insertion
void ICTree::update(int minT, int maxT) {
	if (!this->root) {
		return;
	}
	queue<NewTNode*> q;
	NewTNode *now = this->root, *temp;
	//now->maxV = maxT;
	//now->minV = minT;
	q.push(now);
	while (!q.empty()) {
		now = q.front();
		if (now->right) {//right subtree
			temp = now->right;
			//temp->maxV = now->maxV;
			//temp->minV = now->key.endT + 1;
			q.push(temp);
		}
		if (now->left) {//left subtree
			temp = now->left;
			//temp->maxV = now->key.startT - 1;
			//temp->minV = now->minV;
			q.push(temp);
		}
		q.pop();
	}
}

//maintain the property of red-black
void ICTree::insertFixUp(NewTNode* &mynode) {
	NewTNode* node = mynode;
	while (node->parent != NULL && node->parent->color) {
		if (node->parent == node->parent->parent->left) {//left subtree
			/*if node->parent exists, node->parent->parent must exist,
			because node->parent->color==red and
			node->parent can't be the root
			*/
			NewTNode* uncle = node->parent->parent->right;
			if (uncle&&uncle->color) {//uncle can be NULL
				uncle->color = false;
				node->parent->color = false;
				node->parent->parent->color = true;
				node = node->parent->parent;
			}
			else {
				if (node == node->parent->right) {//right subtree
					node = node->parent;
					lRotate(node);
				}
				node->parent->color = false;
				node->parent->parent->color = true;
				rRotate(node->parent->parent);
			}
		}
		else {//right subtree
			NewTNode* uncle = node->parent->parent->left;
			if (uncle&&uncle->color == true) {//uncle can be NULL
				uncle->color = false;
				node->parent->color = false;
				node->parent->parent->color = true;
				node = node->parent->parent;
			}
			else {
				if (node == node->parent->left) {//right subtree
					node = node->parent;
					rRotate(node);
				}
				node->parent->color = false;
				node->parent->parent->color = true;
				lRotate(node->parent->parent);
			}
		}
	}
	if (this->root->parent)//change the root ptr
		this->root = this->root->parent;
	this->root->color = false;//set the color of root
}

void ICTree::release(NewTNode* &node) {
	if (node) {
		release(node->right);
		release(node->left);
		delete node;
		node = NULL;
	}
}
#pragma endregion

//encapsulation of insertion
void ICTree::insert(const Intv& val) {
	if (!this->root) {
		this->root = DBG_NEW NewTNode(val);
		insertFixUp(this->root);
		return;
	}
	NewTNode *now = this->root;
	NewTNode *node;
	while (now != NULL) {
		if (val > now->key) {//right subtree
			if (now->right) {
				now = now->right;
			}
			else {//null
				now->right = DBG_NEW NewTNode(val, now);
				node = now->right;
				break;
			}
		}
		else {//left subtree
			if (now->left) {
				now = now->left;
			}
			else {//null
				now->left = DBG_NEW NewTNode(val, now);
				node = now->left;
				break;
			}
		}
	}
	insertFixUp(node);
}

#pragma region used in general case
/*search if exists a interval of one node contain [startT,endT]
and return the label,interval's start time and end time */
bool ICTree::newContain(const int startT, const int endT,
	Label& edgeType, int& intvStartT, int& intvEndT){
	NewTNode *now = this->root;
	if (!now)return false;
	queue<NewTNode*> q;
	q.push(now);
	Intv* intvPtr;
	int tempStartT, tempEndT;
	while (!q.empty()) {
		now = q.front();
		intvPtr = &now->key;
		tempStartT = intvPtr->startT;
		tempEndT = intvPtr->endT;
		if (startT <= tempEndT &&tempStartT <= endT) {//intersection relationship
			if (tempStartT <= startT && endT <= tempEndT) {//contain relationship
				edgeType = intvPtr->value;
				intvStartT = tempStartT;
				intvEndT = tempEndT;
				return true;
			}
			edgeType = intvPtr->value;
			intvStartT = tempStartT;
			intvEndT = tempEndT;
			return false;
		}
		q.pop();
		if (now->left&&endT <= intvPtr->startT)//left subtree
			q.push(now->left);
		else if (now->right)//right subtree
			q.push(now->right);
	}
	return false;
}
#pragma endregion

void ICTree::print() {
	if (!this->root) { cout << "empty tree" << endl; return; }
	queue<NewTNode* > q;
	q.push(this->root);
	while (!q.empty()) {
		NewTNode* now = q.front();
		q.pop();
		cout << now << endl;
		if (now->left)q.push(now->left);
		if (now->right)q.push(now->right);
	}
}

//copy the information in copynode to node
void ICTree::copy(NewTNode* &parent,
	NewTNode* &node, NewTNode* &copynode) {
	node->color = copynode->color;
	node->parent = parent;
	if (!copynode->left) {
		node->left = NULL;
	}
	else {
		node->left = DBG_NEW NewTNode(copynode->left->key);
		copy(node, node->left, copynode->left);
	}
	if (!copynode->right) {
		node->right = NULL;
	}
	else {
		node->right = DBG_NEW NewTNode(copynode->right->key);
		copy(node, node->right, copynode->right);
	}
}

/*search if one node contain the time
	and return a interval if true*/
bool ICTree::search(Intv& intv, int time) {
	NewTNode *now = this->root;
	if (!now) return false;
	queue<NewTNode*> q;
	q.push(now);
	Intv* intvPtr;
	while (!q.empty()) {
		now = q.front();
		q.pop();
		intvPtr = &now->key;
		if (time <= intvPtr->endT&&intvPtr->startT <= time) {
			intv.startT = intvPtr->startT;
			intv.endT = intvPtr->endT;
			intv.value = intvPtr->value;
			return true;
		}
		if (now->left&&time < intvPtr->startT)//left subtree
			q.push(now->left);
		else if (now->right)//right subtree
			q.push(now->right);
	}
	return false;
}

/*search if one node contain the time with the fixed label
	and return a interval if true */
bool ICTree::search(Label edgeType, Intv& intv, int time) {
	NewTNode *now = this->root;
	if (!now) return false;
	queue<NewTNode*> q;
	q.push(now);
	Intv* intvPtr;
	while (!q.empty()) {
		now = q.front();
		q.pop();
		intvPtr = &now->key;
		if (time <= intvPtr->endT&&intvPtr->startT <= time && edgeType == intvPtr->value) {
			intv.startT = intvPtr->startT;
			intv.endT = intvPtr->endT;
			/*intv.value = intvPtr->value;*/
			return true;
		}
		if (now->left&&time < intvPtr->startT)//left subtree
			q.push(now->left);
		if (now->right&&time > intvPtr->endT)//right subtree
			q.push(now->right);
	}
	return false;
}

//update interval's endT of nodes
void ICTree::updateNode(Intv& intv, int newEndT) {
	NewTNode *now = this->root;
	while (now) {
		if (intv.startT > now->key.startT) {//right subtree
			if (now->right) {
				now = now->right;
			}
			else {//impossible condition
				cout << "interval doesn't exist" << endl;
				exit(-1);
			}
		}
		else if (intv.startT < now->key.startT) {//left subtree
			if (now->left) {
				now = now->left;
			}
			else {//impossible condition
				cout << "interval doesn't exist" << endl;
				exit(-1);
			}
		}
		else {
			now->key.endT = newEndT;
			break;
		}
	}
}

//
//int main() {
//	
//	NewTree* a = new NewTree();
//	a->insert(Intv(1, 2, 1));
//	a->insert(Intv(3, 5, 1));
//	a->insert(Intv(6, 7, 1));
//	a->insert(Intv(8, 12, 1));
//	a->insert(Intv(13, 14, 1));
//	a->insert(Intv(15, 15, 1));
//	a->insert(Intv(16, 24, 1));
//	a->insert(Intv(25, 25, 1));
//	a->insert(Intv(26, 33, 1));
//	a->insert(Intv(33, 35, 1));
//	a->print();
//	cout << "==================================\n";
//	vector<Intv> result;
//	a->searchAndIntersect(result,2,23,3);
//	vector<Intv>::iterator iter= result.begin();
//	for (; iter != result.end(); iter++) {
//		cout << *iter << endl;
//	}
//	system("pause");
//}