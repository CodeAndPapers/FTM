#pragma once
#include "stdafx.h"
#define LINE_LENGTH 1000
#define SEP_CHAR ','
#define STR2INT(a) Util::stringToInt(a)
#define STR2BOOL(a) Util::stringToBool(a)

using namespace std;
class Util {
public:
	
	//transform char* to int
	inline static int stringToInt(char* str) {
		return atoi(str);
	}

	//transform char* to bool
	inline static bool stringToBool(char* str) {
		return 0!=atoi(str);
	}
	
	//print exception
	inline static void printError(const exception& e) {
		cout <<"exception caught:"<< e.what() << endl;
	}
	
	//return the maximum number among a,b,c
	inline static int getMax(int a,int b,int c) {
		int max = a > b ? a : b;
		return max > c ? max : c;
	}
	
	//return the minimum number among a,b,c
	inline static int getMin(int a, int b, int c) {
		int min = a < b ? a : b;
		return min < c ? min : c;
	}
};

