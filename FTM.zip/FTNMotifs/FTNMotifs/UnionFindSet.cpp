#include"UnionFindSet.h"
#include"stdafx.h"

#pragma once
//find the root of the node whose position is num
int UnionFindSet::find(int num) {
	if (num >= size) return -1;
	if (parent[num] == -1) return -1;
	int root = num;
	while (root != parent[root])
		root = parent[root];
	int temp=num,p;
	while (temp != root) {
		p = parent[temp];
		parent[temp] = root;
		temp = p;
	}
	return parent[num];
}
//union two trees where two nodes locate
void UnionFindSet::unionfind(int a, int b) {
	if (parent[a] == -1 && parent[b] == -1) {
		parent[a] = parent[b] = b;
		depth[b] += 1;
	}
	else if (parent[a] == -1) {
		parent[a] = parent[b];
		depth[b] += 1;
	}
	else if (parent[b] == -1) {
		parent[b] = parent[a];
		depth[a] += 1;
	}
	else {
		int p_a = find(a);
		int p_b = find(b);
		if (p_a == p_b)return;
		if (depth[p_a] > depth[p_b]) {
			parent[p_b] = parent[p_a];
		}
		else if (depth[p_a] < depth[p_b]) {
			parent[p_a] = parent[p_b];
		}
		else {
			parent[p_a] = parent[p_b];
			depth[p_b] += 1;
		}
	}
}

/*union two trees where two nodes locate
	return the old root of tree
*/
int UnionFindSet::newUnionVertexs(int a, int b) {
	if (parent[a] == -1 && parent[b] == -1) {
		parent[a] = parent[b] = b;
		depth[b] += 1;
	}
	else if (parent[a] == -1) {
		parent[a] = parent[b];
		depth[b] += 1;
	}
	else if (parent[b] == -1) {
		parent[b] = parent[a];
		depth[a] += 1;
	}
	else {
		int p_a = find(a);
		int p_b = find(b);
		if (p_a == p_b)return -1;
		int rtn;
		if (depth[p_a] > depth[p_b]) {
			rtn = parent[p_b];
			parent[p_b] = parent[p_a];
		}
		else if (depth[p_a] < depth[p_b]) {
			rtn = parent[p_a];
			parent[p_a] = parent[p_b];
		}
		else {
			rtn = parent[p_a];
			parent[p_a] = parent[p_b];
			depth[p_b] += 1;
		}
		return rtn;
	}
	return -1;
}