#include "FindTNMotif.h"
#include "TGraphUEL.h"
//#include "TGraphUNewStruct.h"
//#include "TGraphUNewStructC.h"
#include "TGraphUICTree.h"
#include "stdafx.h"

#pragma region parameters initialization
int FindTNMotif::k = DEFAULT_K;
long long FindTNMotif::motifNumber = 0;
int FindTNMotif::output = 0;
//bool FindTNMotif::isEdgeTypeFixed = false;
char FindTNMotif::outputSrc[FILE_NAME_LENGTH] = OUTPUT_FILE;
#pragma endregion 

#pragma region static algorithm

/*  @parameter:
	graph: input temporal graph
	resultLen: size of final result
	//fixLabel: fixed label
	methodId=//1: L2R scheme
			=2: FTM
*/
void FindTNMotif::generalCase(TGraph*& graph, vec(TNMotif*)*& result/*,
	i2bHMap& fixLabel,int methodId*/ ) {
	int startT = graph->getStartT(), endT = graph->getEndT();
	//if (methodId == 1) {
	//	//L2R
	//	graph->getAllMotifsM1(k,  result,/* fixLabel, isEdgeTypeFixed,*/
	//		motifNumber, startT, endT);
	//}
	//else {
		//FTM
		graph->getAllMotifsM2(k,  result,/* fixLabel, isEdgeTypeFixed,*/
			motifNumber, startT , endT);
	//}
}
#pragma endregion

#pragma region dynamic algorithm
/*dynamic general case(snapshots increase)
	@parameter:
	graph: input temporal graph(updated)
	result: result
	newResult: new result
	oriEndT: original ending timestamp of temporal graph
	//fixLabel: fixed label
	methodId=//1: L2R
			=2: DFTM
*/
void FindTNMotif::dynamicAlgorithmGC_graph(TGraph*& graph,
	vec(TNMotif*)*& result, vec(TNMotif*)*& newResult, 
	int oriEndT/*, i2bHMap& fixLabel, int methodId*/) {
	int startT = graph->getStartT();
	int endT = graph->getEndT();
	int lastRow = oriEndT - k + 1;

	#pragma region original result
	for (int i = startT; i <= lastRow; i++) {
		int first = i + FindTNMotif::k - 1;
		int tempPos = resultPos(i, first, startT, oriEndT, FindTNMotif::k) - 1;
		int nowPos = resultPos(i, first, startT, endT, FindTNMotif::k) - 1;
		for (int j = first; j <= oriEndT; j++) {
			tempPos++;
			nowPos++;
			int resultSize = (int)result[tempPos].size();
			for (int s = 0; s < resultSize; s++) {
				newResult[nowPos].emplace_back(result[tempPos][s]);
			}
			result[tempPos].clear();
			if(j < oriEndT)
				FindTNMotif::motifNumber += resultSize;
		}
	}
	delete[] result;
	#pragma endregion

	#pragma region update result
		//if (methodId == 1) {//L2R
		//	//row number<=T-k+1
		//	graph->getAllMotifsDynamicGM1(k, newResult,
		//		oriEndT, /*fixLabel, isEdgeTypeFixed,*/ FindTNMotif::motifNumber);
		//	//row number>T-k+1
		//	graph->getAllMotifsM1(k, newResult,
		//		/*fixLabel, isEdgeTypeFixed,*/ FindTNMotif::motifNumber,
		//		oriEndT - k + 2, endT);
		//}
		//else if (methodId == 2) {//DFTM
			//row number<=T-k+1
			graph->getAllMotifsDynamicGM2(k, newResult,
				 oriEndT, /*fixLabel, isEdgeTypeFixed, */FindTNMotif::motifNumber);
			//row number>T-k+1
			graph->getAllMotifsM2(k, newResult,
				/*fixLabel, isEdgeTypeFixed,*/ FindTNMotif::motifNumber,
				oriEndT - k + 2, endT);
		//}
	#pragma endregion
}
#pragma endregion 